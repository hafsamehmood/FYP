<?php
    include('dbh.php');
    $women_clothsQ = mysqli_query($con, "SELECT DISTINCT(brand) FROM women_cloths") or die(mysqli_error($con));
    $women_shoesQ = mysqli_query($con, "SELECT DISTINCT(brand) FROM women_shoes") or die(mysqli_error($con));
    $men_clothsQ = mysqli_query($con, "SELECT DISTINCT(brand) FROM men_cloths") or die(mysqli_error($con));
    $men_shoesQ = mysqli_query($con, "SELECT DISTINCT(brand) FROM men_shoes") or die(mysqli_error($con));
    $kids_clothsQ = mysqli_query($con, "SELECT DISTINCT(brand) FROM kids_cloths") or die(mysqli_error($con));

    $women_clothsA = [];
    while($row=mysqli_fetch_array($women_clothsQ))
    {
        array_push($women_clothsA,$row['brand']);
    }

    $women_shoesA = [];
    while($row=mysqli_fetch_array($women_shoesQ))
    {
        array_push($women_shoesA,$row['brand']);
    }

    $men_clothsA = [];
    while($row=mysqli_fetch_array($men_clothsQ))
    {
        array_push($men_clothsA,$row['brand']);
    }

    $men_shoesA = [];
    while($row=mysqli_fetch_array($men_shoesQ))
    {
        array_push($men_shoesA,$row['brand']);
    }

    $kids_clothsA = [];
    while($row=mysqli_fetch_array($kids_clothsQ))
    {
        array_push($kids_clothsA,$row['brand']);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .cart
{
padding: 10px;
position: absolute;
left: 535px;
z-index: 999;
}
.searchBtn
{
    margin-left: 0;
    border-radius: 25px;
    padding: 5px 10px 5px 10px;
    margin-top: 5px;
    font-weight: bold;
}
#speechToText
{
    padding: 5px 10px 5px 10px;
    border-radius: 25px;
}
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg  ">
            <a class="navbar-brand" href="#"><img src="BootStrap Files/img/logo8-removebg-preview.png" class="img-fluid"
                    alt="" height="40px" width="40px"></a>

      <!-- <div class="cart "> -->
      <a class="navbar-brand cart" onclick="record()" href="#">
        <img src="BootStrap Files/img/VS.png" alt="Cart" height="30px" width="30px">
</a>
            <!-- </div> -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="Home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <!-- <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              New Arrivals
            </a>
            <div class="dropdown-menu dropdown-content" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="#">Mens</a>
              <a class="dropdown-item" href="#">Womens</a>
          </li> -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="menu" role="button" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            Women
                        </a>
                        <ul class="dropdown-menu dropdown-content">
                            <li class="dropdown-item dropdown-submenu">
                                <a href="womensStiched.php" data-toggle="dropdown">Clothes</a>
                                <ul class="dropdown-menu dropdown-contentW">
                                    <?php 
                                        $women_clothsAppend = '';
                                        for ($i=0; $i < count($women_clothsA); $i++) { 
                                            $women_clothsAppend .= '
                                                <li class="dropdown-item">
                                                    <a href="products.php?category=women_cloths&brand='.$women_clothsA[$i].'">'.$women_clothsA[$i].'</a>
                                                </li>
                                            ';
                                        }

                                        echo $women_clothsAppend;
                                    ?>
                                    <!-- <li class="dropdown-item">
                                    <a href="womensStiched.php">Gull Ahmad</a>
                                    </li>
                                    <li class="dropdown-item">
                                    <a href="WomensUnstiched.php">Cross stitch</a>
                                    </li> -->
                                </ul>
                            </li>
                            <li class="dropdown-item dropdown-submenu">
                                <a href="womensSandle.php" data-toggle="dropdown">Shoes</a>
                                <ul class="dropdown-menu dropdown-contentWShoe">
                                <?php 
                                        $women_shoesAppend = '';
                                        for ($i=0; $i < count($women_shoesA); $i++) { 
                                            $women_shoesAppend .= '
                                                <li class="dropdown-item">
                                                    <a href="products.php?category=women_shoes&brand='.$women_shoesA[$i].'">'.$women_shoesA[$i].'</a>
                                                </li>
                                            ';
                                        }

                                        echo $women_shoesAppend;
                                    ?>
                                    <!-- <li class="dropdown-item">
                                        <a href="womensSandle.php">Raja Rani</a>
                                    </li> -->
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <!--  -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="menu" role="button" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            Men
                        </a>
                        <ul class="dropdown-menu dropdown-content">
                            <li class="dropdown-item dropdown-submenu">
                                <a href="mensUnstiched.php" data-toggle="dropdown">Clothes</a>
                                <ul class="dropdown-menu dropdown-contentMCloth">
                                    <?php 
                                        $men_clothsAppend = '';
                                        for ($i=0; $i < count($men_clothsA); $i++) { 
                                            $men_clothsAppend .= '
                                                <li class="dropdown-item">
                                                    <a href="products.php?category=men_cloths&brand='.$men_clothsA[$i].'">'.$men_clothsA[$i].'</a>
                                                </li>
                                            ';
                                        }

                                        echo $men_clothsAppend;
                                    ?>
                                    <!-- <li class="dropdown-item">
                                        <a href="mensUnstiched.php">Ittehad</a>
                                    </li> -->
                                </ul>
                            </li>
                            <li class="dropdown-item dropdown-submenu">
                                <a href="MensShoes.php" data-toggle="dropdown">Shoes</a>
                                <ul class="dropdown-menu dropdwon-contentMShoe">
                                    
                                    <?php 
                                        $men_shoesAppend = '';
                                        for ($i=0; $i < count($men_shoesA); $i++) { 
                                            $men_shoesAppend .= '
                                                <li class="dropdown-item">
                                                    <a href="products.php?category=men_shoes&brand='.$men_shoesA[$i].'">'.$men_shoesA[$i].'</a>
                                                </li>
                                            ';
                                        }

                                        echo $men_shoesAppend;
                                    ?>
                                    
                                    <!-- <li class="dropdown-item">
                                        <a href="MensShoes.php">Chief boot house</a>
                                    </li> -->
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <!--  -->
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Kids
                        </a>
                        <ul class="dropdown-menu dropdown-content">
                            <li class="dropdown-item dropdown-submenu">
                                <a href="mensUnstiched.php" data-toggle="dropdown">Clothes</a>
                                <ul class="dropdown-menu dropdown-contentMCloth">
                                    <?php 
                                        $kids_clothsAppend = '';
                                        for ($i=0; $i < count($kids_clothsA); $i++) { 
                                            $kids_clothsAppend .= '
                                                <li class="dropdown-item">
                                                    <a href="products.php?category=kids_cloths&brand='.$kids_clothsA[$i].'">'.$kids_clothsA[$i].'</a>
                                                </li>
                                            ';
                                        }

                                        echo $kids_clothsAppend;
                                    ?>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <div class="Searchbar">
                        <!--<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">-->
                        <!--<a href="#"> <img src="BootStrap Files/img/Search.png" alt="SearchIcon" height="25px" width="25px"></a>-->

                        <form id="q" method="post" action='search.php'>
                        <input type="text" name="query" id="speechToText" placeholder="Search here"
                                >
                                <input type="submit" class="searchBtn" name="user_search" value="Search" />
                        </form>
                        <!-- Below is the script for voice recognition and conversion to text-->
                        <script>
                        function record() {
                            var recognition = new webkitSpeechRecognition();
                            recognition.lang = "en-GB";

                            recognition.onresult = function(event) {
                                // console.log(event);
                                document.getElementById('speechToText').value = event.results[0][0].transcript;
                            }
                            recognition.start();

                        }
                        </script>
                    </div>

                </ul>

                <!-- <form class="form-inline my-2 my-lg-0">
                    <span class="nav-item dropdown user">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="BootStrap Files/img/stick-man.png" alt="User" height="20px" width="20px">
                            USER
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="signup.php">Sign Up</a>
                    </span>
                </form> -->
            </div>
        </nav>
</body>
</html>
