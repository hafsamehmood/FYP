<!-- Footer Start -->
<div class="footer-section">
    <div class="row">
        <div class="col-lg-3 col-md-3 col-12">
            <h6>Help</h6>
            <ul>
                <li>Store Location</li>
                <li>Click & Collect</li>
                <li>Deleviery & Returns</li>
                <li>Shipment Details</li>
                <li>Technical Support</li>
                <li>Contact us</li>
                <li>FAQs</li>
            </ul>
        </div>

        <div class="col-lg-3 col-md-3 col-12">
            <h6>About</h6>
            <ul>
                <li>Store Location</li>
                <li>Click & Collect</li>
                <li>Deleviery & Returns</li>
                <li>Shipment Details</li>
                <li>Technical Support</li>
                <li>Contact us</li>
                <li>FAQs</li>
            </ul>
        </div>

        <div class="col-lg-3 col-md-3 col-12">
            <h6>Resources</h6>
            <ul>
                <li>Store Location</li>
                <li>Click & Collect</li>
                <li>Deleviery & Returns</li>
                <li>Shipment Details</li>
                <li>Technical Support</li>
                <li>Contact us</li>
                <li>FAQs</li>
            </ul>
        </div>

        <div class="col-lg-3 col-md-3 col-12">
            <h6>Legal</h6>
            <ul>
                <li>Store Location</li>
                <li>Click & Collect</li>
                <li>Deleviery & Returns</li>
                <li>Shipment Details</li>
                <li>Technical Support</li>
                <li>Contact us</li>
                <li>FAQs</li>
            </ul>
        </div>
    </div>
</div>
<div class="social-icons bg-dark">
    <div class="container">
        <h1>JOIN US ON SOCIAL MEDIA </h1>
        <a href="#" class="fa fa fa-facebook"></a>
        <a href="#" class="fa fa-google"></a>
        <a href="#" class="fa fa-youtube"></a>
        <a href="#" class="fa fa-instagram"></a>
        <p>&#169 2020 <span style="color:yellow"> COST CUTTERS </span> all rights reserved</p>
        <a href="#"><img src="BootStrap Files/img/Subsarrow-removebg-preview.png" class="fixed-btn" height="50px"
                width="50px"></a>
    </div>
</div>
<script src="BootStrap Files/jquery.slim.min.js"></script>
<script src="BootStrap Files/popper.min.js"></script>
<script src="BootStrap Files/bootstrap.min.js"></script>
<script>
$('.dropdown-submenu > a').on("click", function(e) {
    var submenu = $(this);
    $('.dropdown-submenu .dropdown-menu').removeClass('show');
    submenu.next('.dropdown-menu').addClass('show');
    e.stopPropagation();
});

$('.dropdown').on("hidden.bs.dropdown", function() {
    // hide any open menus when parent closes
    $('.dropdown-menu.show').removeClass('show');
});
</script>