$("site-slider-2").not(".slick-intialized").slick({
autoplay: true,
prevArrow: " .prev",
prevArrow: " .next",
slidesToShow:5,
slidesToScroll:1,
autoplayspeed:3000
});