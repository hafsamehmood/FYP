<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>ShoppingKro.com</title>
  <link rel="stylesheet" href="static/css/chat.css">
  <!-- <link rel="stylesheet" href="static/css/home.css">  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="BootStrap Files/bootstrap.min.css">
  <link rel="stylesheet" href="Home.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <script type="text/javascript" src="https://code.jquery.com/jquery-1.8.2.js"></script>

<!--    //pop up-->
<style type="text/css">
        #overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #000;
            filter:alpha(opacity=70);
            -moz-opacity:0.7;
            -khtml-opacity: 0.7;
            opacity: 0.7;
            z-index: 100;
            display: none;
        }
        .cnt223 a{
            text-decoration: none;
        }
        .popup{
            width: 100%;
            margin: 0 auto;
            display: none;
            position: fixed;
            z-index: 101;
        }
        .cnt223{
            min-width: 600px;
            width: 600px;
            min-height: 150px;
            margin: 100px auto;
            background: #f3f3f3;
            position: relative;
            z-index: 103;
            padding: 15px 35px;
            border-radius: 5px;
            box-shadow: 0 2px 5px #000;
        }
        .cnt223 p{
            clear: both;
            color: #555555;
            /* text-align: justify; */
            font-size: 20px;
            font-family: sans-serif;
        }
        .cnt223 p a{
            color: #d91900;
            font-weight: bold;
        }
        .cnt223 .x{
            float: right;
            height: 35px;
            left: 22px;
            position: relative;
            top: -25px;
            width: 34px;
        }
        .cnt223 .x:hover{
            cursor: pointer;
        }
        /* Social Icons Start */
.fa {
    padding: 20px;
    font-size: 30px;
    width: 60px;
    text-align: center;
    text-decoration: none;
    margin: 5px 2px;
    background: rgb(254,194,2);
      color: black;
      text-align: center;
  }
  .fa-facebook:hover {
    background: #3B5998;
    color:white;
  }
  
  
  .fa-google:hover {
    background: #dd4b39;
    color:white;
  }
  
  .fa-youtube:hover {
    background: #bb0000;
    color:white;
  }
  
  .fa-instagram:hover {
    background: #125688;
    color:white;
  }
  .social-icons .container
  {
      text-align: center;
  }
  .social-icons
  {
      padding: 50px 0;
  }
  .social-icons .container h1
  {
      text-align: center;
      color: white;
      padding-bottom: 30px;
  }
  .social-icons .container p
  {
      text-align: center;
      color: white;
      font-size: 1.2rem;
      padding-top: 30px;
  }
  .fixed-btn
  {
      position: absolute;
      right: 30%;
      transform: rotate(-90deg);
      margin-bottom: 30px;
  }
  .social-icons .container
  { 
      padding-bottom: 20px;
  }
/* Social Icones End */
/* POP UP */
.cnt223
{
  background-color: lightsteelblue;
}
.header-text
  {
      position: absolute;
      top: 160px;
      left: 110px;
      text-align: justify;
    
  }
/* POP UP  */
    </style>
</head>

<body onload="Popup()">
  <!-- Header Start -->
  <!-- DiaLog Starts -->
  
  <!-- Dialog Ends -->

<!--  pop up Ahmad-->
  <div class='popup'>
      <div class='cnt223'>
          <h3>Subscribe us</h3>
<!--          <p>-->
          Please Subscribe us to get notified by the latest sales in your email.
            <br><br>
          <h4> Email:</h4>
          <form action="functions/functions.php" method="post">
              <input type="email" name="user_email" placeholder="Please enter your email">
              <!--<select name="region" id="region">-->
              <!--<option value="volvo">Choose your region</option>-->
              <!--<option value="volvo">Pakistan</option>-->
              <!--<option value="saab">Anywhere else in the world</option>-->
              <!--</select>-->
              <!--<input type="password" class="form-control" name="user_password" placeholder="Password"><br>-->
              <br><br><input type="submit" name="user_submit_singup" value="Submit" class="btn btn-primary">
              <!--                    <a href="signup.php" name="" value="Sign up" class="btn btn-primary" style="float: right" >Sign Up</a>-->
              <!-- <a style="float: right;" href="signup.html">Sign Up</a> -->
          </form>
           <a href='' class='close'> Close  </a>
          </p>
      </div>
  </div>

  <!-- Header Start -->
  <div class="header-part">
    <!-- NavBar Start -->
    <!-- NavBar Start -->
    <?php include('navBar.php'); ?>
    <!-- NavBar Ends -->
    <!-- <div class="module">
<h2 class="stripe-4">Other Direction, Different Angle</h2>
<p>If the colors have a lot of contrast, this one can be very jagged. Even normal tricks like translateZ(0) don't work to fix it.</p>
</div> -->
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12 d-none d-md-block">
        <h1 class="header-text" style="font-weight: bold; line-height:4.3rem;  font-family: Sans-serif, serif;">
         <span style="font-size: 5rem;"> SHOP THE </span><br> <span style="font-size: 4rem;font-family: cursive; color:#dd4b39 ">DISCOUNT </span> <br> <span style=" font-family: arial;">Avail the live sales</span> 
        </h1>
        <div class="header-line d-none d-xl-block" style="top: 310px;"><span></span></div>
        <!-- <div class="header-btn">
          <a href="#" class="btn btn-dark waves-effect waves-light">
            <h3>NEW ARRIVALS</h3>
          </a>
        </div> -->
        <!-- <div class="header-strips d-none d-lg-block"><span></span></div> -->
      </div>
      <!-- Caresoul Start -->
      <div class="col-lg-6 col-md-6 col-12 carousel-part">
        <div id="carouselExampleCaptions" class="carousel   carousel-fade" data-ride="carousel">

          <div class="carousel-inner">
            <div class="carousel-item active" data-interval="1000">
              <img src="BootStrap Files/img/mens-removebg-preview.png" class="d-block " alt="...">
              <div class="carousel-caption ">
                <a href="#"><img src="BootStrap Files/img/khadi3-removebg-preview.png" alt="KHADII"
                    class="header-brand img-fluid d-none d-lg-block" height="150px" width="150px"></a>
                <h1 class="d-none d-lg-block">Visit and Shop the Discount</h1>
                <!-- <a href="#" class="btn btn-warning">SHOP NOW</a> -->
              </div>
            </div>
            <div class="carousel-item" data-interval="1000">
              <img src="BootStrap Files/img/women-removebg-preview.png" class="d-block header-women" alt="...">
              <div class="carousel-caption ">
                <a href="#"><img src="BootStrap Files/img/Mariab-removebg-preview.png" alt="MARIA B"
                    class="header-brand img-fluid d-none d-lg-block" height="150px" width="150px"></a>
                <h1 class="d-none d-lg-block">Find Sale on Your Favourite Brands</h1>
                <!-- <a href="#" class="btn btn-warning">SHOP NOW</a> -->
              </div>
            </div>
            <div class="carousel-item" data-interval="1000">
              <img src="BootStrap Files/img/shoe2-removebg-preview.png" class="d-block header-women" alt="...">
              <div class="carousel-caption ">
                <a href="#"><img src="BootStrap Files/img/puma-removebg-preview.png" alt="PUMA"
                    class="header-brand img-fluid d-none d-lg-block" height="150px" width="150px"></a>
                <h1 class="d-none d-lg-block">Shop The Discount on Just one click from desired websites.</h1>
                <!-- <a href="#" class="btn btn-warning">SHOP NOW</a> -->
              </div>
            </div>
          </div>

        </div>
        <!-- <div class="carousel-strips1 d-none d-lg-block"><span></span></div> -->
        <div class="carousel-strips2 d-none d-lg-block"><span></span></div>
      </div>
      <!-- Caresoul Ends -->
    </div>
  </div>
  <!-- Header Ends -->

  <!-- Shop BY Categories Start-->
  <div class="women-section">
    <div class='container'>
      <h1 class="font-weight-bold text-center women-heading">WOMAN</h1>
      <div class="row">
        <div class="col-lg-4 col-md-4 col-12">
          <div class="card" style="width: 20rem;">
            <img src="BootStrap Files/img/w1.jpg" class="card-img-top" height="220px">
            <div class="card-body text-center">
              <h3 class="card-title"><a href="womensStiched.php">PRET</a></h3>
              <p class="card-text">Celebrate the seasons festivities with our ready-to-wear
                collection featuring summer shades, pretty prints and
                defined silhouettes.</p>
              <!-- <a href="#" class="btn btn-warning font-weight-bold">SHOP NOW</a> -->
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-4 col-12">
          <div class="card" style="width: 20rem;">
            <img src="BootStrap Files/img/w2.jpg" class="card-img-bottom" height="220px">
            <div class="card-body text-center">
              <h3 class="card-title"><a href="WomensUnstiched.php">UNSTICHED</a></h3>
              <p class="card-text">The real summer perfection lies in soft
                lawn fabrics and beautiful prints that can be tailored as per
                your unique style..</p>
              <!-- <a href="#" class="btn btn-warning font-weight-bold">SHOP NOW</a> -->
            </div>
          </div>
        </div>

        <div class="col-lg-4 col-md-4 col-12">
          <div class="card" style="width: 20rem;">
            <img src="BootStrap Files/img/w3.jpg" class="card-img-top" height="220px">
            <div class="card-body text-center">
              <h3 class="card-title"><a href="#">KHASS</a></h3>
              <p class="card-text">The real summer perfection lies in soft
                lawn fabrics and beautiful prints that can be tailored as per
                your unique style..</p>
              <!-- <a href="#" class="btn btn-warning font-weight-bold">SHOP NOW</a> -->
            </div>
          </div>
        </div>

        
      </div>
    </div>
  </div>
  <!-- Shop BY Categories Ends -->
  <!-- Kids Section Start -->
  <div class="kids-section">
    <div class="tcenter">
      <div class="kids-content text-center">
        <h1>KIDS</h1>
        <p>This season shop for Khaadi Kids' on-trend outfits
          that reflect your child’s imagination and bring out
          heir vibrant personality.</p>
        <!-- <a href="#" class="btn btn-kids">SHOP NOW</a> -->
      </div>
    </div>
  </div>
  <!-- Kids Section Ends -->

  <!-- Pouplar Products Start-->
  <div class="pouplar-products">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-12 movecenter">
          <div class="ppcontent">
            <h2>Pouplar Products</h2>
            <p>Every Year there are <br> some Products which <br> are highly Pouplar
              This <br> year we have these</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-12">
          <div class="card pouplar-card puma-card" style="width: 20rem; height: 350PX;">
            <img src="BootStrap Files/pouplar products/s1-removebg-preview.png" class="img-fluid card-img-top"
              height="150px">
            <div class="card-body">
              <h4 class="card-title">Sneakers</h4>
             
              <!-- <div class="add-cart">
                <a href="#" class="btn btn-warning add-btn font-weight-bold">Add to Cart</a>
                <img src="BootStrap Files/pouplar products/plus-circular-button.png" class="plus" height="30px"
                  width="30px">
              </div> -->
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 col-12">
          <div class="card pouplar-card khadi-card" style="width: 20rem; height: 350px;">
            <img src="BootStrap Files/pouplar products/k1-removebg-preview.png" class=" card-img-top"
              height="300px">
            <div class="card-body">
              <h4 class="card-title">KHADII LAWN</h4>
              
            
              <!-- <div class="add-cart">
                <a href="#" class="btn btn-warning add-btn font-weight-bold">Add to Cart</a>
                <img src="BootStrap Files/pouplar products/plus-circular-button.png" class="plus" height="30px"
                  width="30px">
              </div> -->
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-3 col-12">
          <div class="card pouplar-card kid-card" style="width: 20rem;height: 350PX; ">
            <img src="BootStrap Files/pouplar products/c1-removebg-preview.png" class="img-fluid card-img-top"
              height="150px">
            <div class="card-body" >
              <h5 class="card-title" style="vertical-align: middle;">KIDS FARAK</h5>
              <!-- <p class="card-text">By MARIA B Brand</p>
              <h6 class="price">RS:4000/-</h6> -->
              <!-- <div class="add-cart">
                <a href="#" class="btn btn-warning add-btn font-weight-bold">Add to Cart</a>
                <img src="BootStrap Files/pouplar products/plus-circular-button.png" class="plus" height="30px"
                  width="30px">
              </div> -->
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
  <!-- Pouplar Products End-->
  <!--Subscribe Section Start-->
<div class="subs-section bg-dark">
<div class="row">
<div class="col-12">
<h1>Join <span class="cc"> COST CUTTERS </span> Family</h1>
<p class="text-center">If you want to recieve  daily deals <br>  packges  discounts emails then <br> Please subscribe.</p>
<div class="box">
<form >
<input type="text"  class="input subs-email" name="" id="" placeholder="Your Email...">
<input type="submit" value="Subscribe" class="input subs-img  ">
</form >
</div>
</div>
</div>
</div>
<!--Subscribe Section Start-->
  <!-- Footer Start -->
<div class="footer-section">
<div class="row"> 
<div class="col-lg-3 col-md-3 col-12">
<h6>Help</h6>
<ul>
  <li>Store Location</li>
  <li>Click & Collect</li>
  <li>Deleviery & Returns</li>
  <li>Shipment Details</li>
  <li>Technical Support</li>
  <li>Contact us</li>
  <li>FAQs</li>
</ul>
</div>

<div class="col-lg-3 col-md-3 col-12">
<h6>About</h6>
<ul>
<li>Store Location</li>
<li>Click & Collect</li>
<li>Deleviery & Returns</li>
<li>Shipment Details</li>
<li>Technical Support</li>
<li>Contact us</li>
<li>FAQs</li>
</ul>
</div>

<div class="col-lg-3 col-md-3 col-12">
<h6>Resources</h6>
<ul>
<li>Store Location</li>
<li>Click & Collect</li>
<li>Deleviery & Returns</li>
<li>Shipment Details</li>
<li>Technical Support</li>
<li>Contact us</li>
<li>FAQs</li>
</ul>
</div>

<div class="col-lg-3 col-md-3 col-12">
<h6>Legal</h6>
<ul>
<li>Store Location</li>
<li>Click & Collect</li>
<li>Deleviery & Returns</li>
<li>Shipment Details</li>
<li>Technical Support</li>
<li>Contact us</li>
<li>FAQs</li>
</ul>
</div>
</div>
</div>
<div class="social-icons bg-dark">
<div class="container">
<h1>JOIN US  ON SOCIAL MEDIA  </h1>
<a href="#" class="fa fa fa-facebook"></a>
<a href="#" class="fa fa-google"></a>
<a href="#" class="fa fa-youtube"></a>
<a href="#" class="fa fa-instagram"></a>
<p>&#169 2020 <span style="color:yellow"> COST CUTTERS </span> all rights reserved</p>
<a href="#"><img src="BootStrap Files/img/Subsarrow-removebg-preview.png" class="fixed-btn" height="50px" width="50px"></a>
</div>
</div>
<!-- Footer End -->
  
  <!-- CHAT BAR BLOCK -->


  <div class="chat-bar-collapsible">
    <button id="chat-button" type="button" class="collapsible">Chat with us!
        <!-- <i id="chat-icon" style="color: #fff;" class="fa fa-fw fa-comments-o"></i> -->
        <img src="BootStrap Files/img/chat2.jpg" height="50px" width="50px" >

    </button>

    <div class="content">
        <div class="full-chat-block">
            <!-- Message Container -->
            <div class="outer-container">
                <div class="chat-container">
                    <!-- Messages -->
                    <div id="chatbox">
                        <h5 id="chat-timestamp"></h5>
                        <p id="botStarterMessage" class="botText"><span>Loading...</span></p>
                    </div>

                    <!-- User input box -->
                    <div class="chat-bar-input-block">
                        <div id="userInput">
                            <input id="textInput" class="input-box" type="text" 
                                placeholder="Tap 'Enter' to send a message">
                            <p></p>
                        </div>

                        <div class="chat-bar-icons">
                            <i id="chat-icon" style="color: crimson;" class="fa fa-fw fa-heart"
                                onclick="heartButton()"></i>
                            
                        </div>
                    </div>

                    <div id="chat-bar-bottom">
                        <p></p>
                    </div>

                </div>
            </div>

        </div>
    </div>
</body>

<!-- PopUp -->

<script type='text/javascript'>
    $(function(){
        var overlay = $('<div id="overlay"></div>');
        overlay.show();
        overlay.appendTo(document.body);
        $('.popup').show();
        $('.close').click(function(){
            $('.popup').hide();
            overlay.appendTo(document.body).remove();
            return false;
        });




        $('.x').click(function(){
            $('.popup').hide();
            overlay.appendTo(document.body).remove();
            return false;
        });
    });
</script>
<!-- <script src="static/scripts/responses.js"></script>
<script src="static/scripts/chat.js"></script> -->
  <script src="BootStrap Files/jquery.slim.min.js"></script>
  <script src="BootStrap Files/popper.min.js"></script>
  <script src="BootStrap Files/bootstrap.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script>

    function show()
    {
        alert('hello');
    }
    $('.dropdown-submenu > a').on("click", function (e) {
      var submenu = $(this);
      $('.dropdown-submenu .dropdown-menu').removeClass('show');
      submenu.next('.dropdown-menu').addClass('show');
      e.stopPropagation();
    });

    $('.dropdown').on("hidden.bs.dropdown", function () {
      // hide any open menus when parent closes
      $('.dropdown-menu.show').removeClass('show');
    });


  </script>

<!-- Chat Bot Script -->
<script>
// Collapsible
var coll = document.getElementsByClassName("collapsible");

for (let i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
        this.classList.toggle("active");

        var content = this.nextElementSibling;

        if (content.style.maxHeight) {
            content.style.maxHeight = null;
        } else {
            content.style.maxHeight = content.scrollHeight + "px";
        }

    });
}

function getTime() {
    let today = new Date();
    hours = today.getHours();
    minutes = today.getMinutes();

    if (hours < 10) {
        hours = "0" + hours;
    }

    if (minutes < 10) {
        minutes = "0" + minutes;
    }

    let time = hours + ":" + minutes;
    return time;
}

// Gets the first message
function firstBotMessage() {
    let firstMessage = "How's it going?"
    document.getElementById("botStarterMessage").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>';

    let time = getTime();

    $("#chat-timestamp").append(time);
    document.getElementById("userInput").scrollIntoView(false);
}

firstBotMessage();

// Retrieves the response
function getHardResponse(userText) {
    let botResponse = getBotResponse(userText);
    let botHtml = '<p class="botText"><span>' + botResponse + '</span></p>';
    $("#chatbox").append(botHtml);

    document.getElementById("chat-bar-bottom").scrollIntoView(true);
}

//Gets the text text from the input box and processes it
function getResponse() {
    let userText = $("#textInput").val();

    if (userText == "") {
        userText = "I love Code Palace!";
    }

    let userHtml = '<p class="userText"><span>' + userText + '</span></p>';

    $("#textInput").val("");
    $("#chatbox").append(userHtml);
    document.getElementById("chat-bar-bottom").scrollIntoView(true);

    setTimeout(() => {
        getHardResponse(userText);
    }, 1000)

}

// Handles sending text via button clicks
function buttonSendText(sampleText) {
    let userHtml = '<p class="userText"><span>' + sampleText + '</span></p>';

    $("#textInput").val("");
    $("#chatbox").append(userHtml);
    document.getElementById("chat-bar-bottom").scrollIntoView(true);

    //Uncomment this if you want the bot to respond to this buttonSendText event
    // setTimeout(() => {
    //     getHardResponse(sampleText);
    // }, 1000)
}

function sendButton() {
    getResponse();
}

function heartButton() {
    buttonSendText("Heart clicked!")
}

// Press enter to send a message
$("#textInput").keypress(function (e) {
    if (e.which == 13) {
        getResponse();
    }
});
  function getBotResponse(input) {
  // Simple responses
  if (input == "hi" || input == "hello")
    {
        return "Hello! How may I help You!";
    } 
    else if (input == "goodbye" || input =="ok" ||  input =="OK" ||  input =="ok thankyou")
    {
        return "Have a nice day!";
    } 
    else if (input == "when will be the sale go live" || input =="when is the sale" ||  input =="how many days left in sale")
    {
        return "All the items here are on sale! ";
    } 
    else if (input == "how will I order this" || input =="how will I order from here" ||  input =="how I am supposed to order this dress")
    {
        return "Kindly click on that respective picture for further info, Thanks!";
    } 
    else if (input == "where is the nearest outlet of ethnic")
    {
        return "https://ethnic.pk/ You will find address here!";
    } 
    else if (input == "where is the nearest outlet of Outfitters")
    {
        return "https://outfitters.com.pk You will find address here!";
    } 
    else if (input == "where is the nearest outlet of Leisure Club")
    {
        return "https://www.leisureclub.pk/ You will find address here!";
    } 
    else if (input == "what is your return and exchange policy")
    {
        return "Kindly click on that respective picture for further info, Thanks!";
    } 
    else
    {
        return "Please Contact at FYP@gmail.com!";
    }
}
</script>
<!-- Chat Bot Script -->

</html>