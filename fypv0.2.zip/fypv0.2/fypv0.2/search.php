<?php
	include('dbh.php');
?>

<?php
if(isset($_POST['user_search']))
{
    session_start();
    $query = $_POST['query'];
    $arr = [];

    $search = mysqli_query($con, "SELECT * FROM women_cloths
        WHERE title LIKE '%".$query."%' OR brand LIKE '%".$query."%'") or die(mysqli_error($con));
    while($row=mysqli_fetch_array($search))
    {
        array_push($arr,[
            'brand'=>$row['brand'],
            'title'=>$row['title'],
            'price'=>$row['price'],
            'oldprice'=>$row['oldprice'],
            'image'=>$row['image'],
            'link'=>$row['link'],
        ]); 
    }

    $search = mysqli_query($con, "SELECT * FROM women_shoes
    WHERE title LIKE '%".$query."%' OR brand LIKE '%".$query."%'" ) or die(mysqli_error($con));
    while($row=mysqli_fetch_array($search))
    {
        array_push($arr,[
            'brand'=>$row['brand'],
            'title'=>$row['title'],
            'price'=>$row['price'],
            'oldprice'=>$row['oldprice'],
            'image'=>$row['image'],
            'link'=>$row['link'],
        ]);
    }

    $search = mysqli_query($con, "SELECT * FROM men_cloths
    WHERE title LIKE '%".$query."%' OR brand LIKE '%".$query."%'" ) or die(mysqli_error($con));
    while($row=mysqli_fetch_array($search))
    {
        array_push($arr,[
            'brand'=>$row['brand'],
            'title'=>$row['title'],
            'price'=>$row['price'],
            'oldprice'=>$row['oldprice'],
            'image'=>$row['image'],
            'link'=>$row['link'],
        ]);
    }

    $search = mysqli_query($con, "SELECT * FROM men_shoes
    WHERE title LIKE '%".$query."%' OR brand LIKE '%".$query."%'" ) or die(mysqli_error($con));
    while($row=mysqli_fetch_array($search))
    {
        array_push($arr,[
            'brand'=>$row['brand'],
            'title'=>$row['title'],
            'price'=>$row['price'],
            'oldprice'=>$row['oldprice'],
            'image'=>$row['image'],
            'link'=>$row['link'],
        ]);
    }

    $search = mysqli_query($con, "SELECT * FROM kids_cloths
    WHERE title LIKE '%".$query."%' OR brand LIKE '%".$query."%'" ) or die(mysqli_error($con));
    while($row=mysqli_fetch_array($search))
    {
        array_push($arr,[
            'brand'=>$row['brand'],
            'title'=>$row['title'],
            'price'=>$row['price'],
            'oldprice'=>$row['oldprice'],
            'image'=>$row['image'],
            'link'=>$row['link'],
        ]);
    }

    $_SESSION['searchRes'] = json_encode($arr);

    header('Location: display.php');
}
?>