<?php

include ('../dbh.php');

if (isset($_POST['user_submit_singup']))
{
//    echo $_POST['user_email'];
    $query = "INSERT INTO `users`(`user_email`) VALUES ('".$_POST['user_email']."')";
    if(mysqli_query($con, $query))
    {
        header("Location: ../Home.php");
    }

}


if (isset($_POST['user_submit_log_in']))

{}

?>