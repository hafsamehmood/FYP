<?php
    $host = 'localhost';
    $database = 'python_php';
    $username = 'root';
    $password = '';

    $con = mysqli_connect($host, $username, $password, $database);
    // echo "$database";
    if ($con->connect_error) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    //die("Connection failed: " . $con->connect_error);
    }
    else
    {
     echo 'connection successfull';
    }
?>