-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2021 at 08:47 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `python_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `kids_cloths`
--

CREATE TABLE `kids_cloths` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `image` longtext DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kids_cloths`
--

INSERT INTO `kids_cloths` (`id`, `title`, `price`, `image`, `brand`) VALUES
(1, 'FRONT BUNCH 2 PCS SUIT', 'Rs.3,356.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/KPS808220A_300x.jpg?v=1615801412', NULL),
(2, 'ZIPPER HOODIE', 'Rs.1,097.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GHK508419_300x.jpg?v=1615800382', NULL),
(3, 'EMBROIDERED PATCH SHIRT', 'Rs.1,197.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BWF511419_300x.jpg?v=1615800295', NULL),
(4, 'BORN TO RULE TEE S/S', 'Rs.906.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BKT816B220A_300x.jpg?v=1615800436', NULL),
(5, '97 FASHION ALL OVER PRINT S/S', 'Rs.906.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BKT807220A_300x.jpg?v=1615801182', NULL),
(6, 'GEOMETRICAL QUILTED GILET', 'Rs.2,697.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BJ601420A_300x.jpg?v=1608186820', NULL),
(7, 'QUILTED PU JACKET', 'Rs.4,497.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BJ603420A_300x.jpg?v=1616416890', NULL),
(8, 'RANI TOP', 'Rs.2,697.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/KPL615420A_300x.jpg?v=1608554560', NULL),
(9, 'SANDY DOUBLE BREASTED COAT', 'Rs.3,897.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GJ601420A_300x.jpg?v=1617361203', NULL),
(10, 'BLUE BALLOON SLEEVE SWEATR TOP', 'Rs.1,917.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GS611420A_300x.jpg?v=1609392751', NULL),
(11, 'RED ROSE SWEATER', 'Rs.2,097.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GS617420A_300x.jpg?v=1609392805', NULL),
(12, 'BASIC TIGHTS', 'Rs.657.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GKL602B420A_300x.jpg?v=1607944479', NULL),
(13, 'BASIC TROUSER', 'Rs.1,317.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GKB606420A_300x.jpg?v=1609392595', NULL),
(14, 'HOODIE JACKET', 'Rs.1,497.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GHK606D420A_95fba90d-fb70-4503-9650-9556d4b7f311_300x.jpg?v=1608616746', NULL),
(15, 'PAPER BAG JEANS', 'Rs.1,317.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GDJ615420A_300x.jpg?v=1609392470', NULL),
(16, 'COLOR BLOCK KNITTED  JUMPER', 'Rs.1,917.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BS608420B_300x.jpg?v=1606400858', NULL),
(17, 'DEATH VADER REVENGE TEE F/S', 'Rs.1,017.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BKT602420B_300x.jpg?v=1606401183', NULL),
(18, 'CANVAS LONG HOODED COAT', 'Rs.3,597.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BJ605420_300x.jpg?v=1606401245', NULL),
(19, 'Teal Smocked Top', 'Rs.  1590', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-016.jpg', NULL),
(20, 'Casual Jeans', 'Rs.  1690', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gdb-024.jpg', NULL),
(21, 'Yellow Floral Top', 'Rs.  1090', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-023_1.jpg', NULL),
(22, 'Minnie Mouse T-Shirt', 'Rs.  1090', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-121.jpg', NULL),
(23, 'Striped Shimmer Top', 'Rs.  2190', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-175.jpg', NULL),
(24, 'Ruffled Seashells Top', 'Rs.  1890', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-019.jpg', NULL),
(25, 'Baby Pink Top', 'Rs.  1790', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-018.jpg', NULL),
(26, 'Multi Floral Top', 'Rs.  1290', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-008.jpg', NULL),
(27, 'Printed Hearts Top', 'Rs.  1290', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-024.jpg', NULL),
(28, 'Embroidered Flamingo Top', 'Rs.  1290', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gkt-009-_1_.jpg', NULL),
(29, 'Floral Embroidered Jeans', 'Rs.  1990', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gdb-019.jpg', NULL),
(30, 'Floral Wonders Top', 'Rs.  1590', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-008.jpg', NULL),
(31, 'FRONT BUNCH 2 PCS SUIT', 'Rs.3,356.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/KPS808220A_300x.jpg?v=1615801412', NULL),
(32, 'ZIPPER HOODIE', 'Rs.1,097.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GHK508419_300x.jpg?v=1615800382', NULL),
(33, 'EMBROIDERED PATCH SHIRT', 'Rs.1,197.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BWF511419_300x.jpg?v=1615800295', NULL),
(34, 'BORN TO RULE TEE S/S', 'Rs.906.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BKT816B220A_300x.jpg?v=1615800436', NULL),
(35, '97 FASHION ALL OVER PRINT S/S', 'Rs.906.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BKT807220A_300x.jpg?v=1615801182', NULL),
(36, 'GEOMETRICAL QUILTED GILET', 'Rs.2,697.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BJ601420A_300x.jpg?v=1608186820', NULL),
(37, 'QUILTED PU JACKET', 'Rs.4,497.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BJ603420A_300x.jpg?v=1616416890', NULL),
(38, 'RANI TOP', 'Rs.2,697.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/KPL615420A_300x.jpg?v=1608554560', NULL),
(39, 'SANDY DOUBLE BREASTED COAT', 'Rs.3,897.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GJ601420A_300x.jpg?v=1617361203', NULL),
(40, 'BLUE BALLOON SLEEVE SWEATR TOP', 'Rs.1,917.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GS611420A_300x.jpg?v=1609392751', NULL),
(41, 'RED ROSE SWEATER', 'Rs.2,097.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GS617420A_300x.jpg?v=1609392805', NULL),
(42, 'BASIC TIGHTS', 'Rs.657.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GKL602B420A_300x.jpg?v=1607944479', NULL),
(43, 'BASIC TROUSER', 'Rs.1,317.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GKB606420A_300x.jpg?v=1609392595', NULL),
(44, 'HOODIE JACKET', 'Rs.1,497.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GHK606D420A_95fba90d-fb70-4503-9650-9556d4b7f311_300x.jpg?v=1608616746', NULL),
(45, 'PAPER BAG JEANS', 'Rs.1,317.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GDJ615420A_300x.jpg?v=1609392470', NULL),
(46, 'COLOR BLOCK KNITTED  JUMPER', 'Rs.1,917.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BS608420B_300x.jpg?v=1606400858', NULL),
(47, 'DEATH VADER REVENGE TEE F/S', 'Rs.1,017.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BKT602420B_300x.jpg?v=1606401183', NULL),
(48, 'CANVAS LONG HOODED COAT', 'Rs.3,597.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BJ605420_300x.jpg?v=1606401245', NULL),
(49, 'Teal Smocked Top', 'Rs.  1590', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-016.jpg', NULL),
(50, 'Casual Jeans', 'Rs.  1690', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gdb-024.jpg', NULL),
(51, 'Yellow Floral Top', 'Rs.  1090', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-023_1.jpg', NULL),
(52, 'Minnie Mouse T-Shirt', 'Rs.  1090', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-121.jpg', NULL),
(53, 'Striped Shimmer Top', 'Rs.  2190', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-175.jpg', NULL),
(54, 'Ruffled Seashells Top', 'Rs.  1890', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-019.jpg', NULL),
(55, 'Baby Pink Top', 'Rs.  1790', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-018.jpg', NULL),
(56, 'Multi Floral Top', 'Rs.  1290', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-008.jpg', NULL),
(57, 'Printed Hearts Top', 'Rs.  1290', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-024.jpg', NULL),
(58, 'Embroidered Flamingo Top', 'Rs.  1290', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gkt-009-_1_.jpg', NULL),
(59, 'Floral Embroidered Jeans', 'Rs.  1990', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gdb-019.jpg', NULL),
(60, 'Floral Wonders Top', 'Rs.  1590', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-008.jpg', NULL),
(61, 'FRONT BUNCH 2 PCS SUIT', 'Rs.3,356.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/KPS808220A_300x.jpg?v=1615801412', NULL),
(62, 'ZIPPER HOODIE', 'Rs.1,097.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GHK508419_300x.jpg?v=1615800382', NULL),
(63, 'EMBROIDERED PATCH SHIRT', 'Rs.1,197.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BWF511419_300x.jpg?v=1615800295', NULL),
(64, 'BORN TO RULE TEE S/S', 'Rs.906.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BKT816B220A_300x.jpg?v=1615800436', NULL),
(65, '97 FASHION ALL OVER PRINT S/S', 'Rs.906.50', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BKT807220A_300x.jpg?v=1615801182', NULL),
(66, 'GEOMETRICAL QUILTED GILET', 'Rs.2,697.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BJ601420A_300x.jpg?v=1608186820', NULL),
(67, 'QUILTED PU JACKET', 'Rs.4,497.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BJ603420A_300x.jpg?v=1616416890', NULL),
(68, 'RANI TOP', 'Rs.2,697.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/KPL615420A_300x.jpg?v=1608554560', NULL),
(69, 'SANDY DOUBLE BREASTED COAT', 'Rs.3,897.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GJ601420A_300x.jpg?v=1617361203', NULL),
(70, 'BLUE BALLOON SLEEVE SWEATR TOP', 'Rs.1,917.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GS611420A_300x.jpg?v=1609392751', NULL),
(71, 'RED ROSE SWEATER', 'Rs.2,097.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GS617420A_300x.jpg?v=1609392805', NULL),
(72, 'BASIC TIGHTS', 'Rs.657.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GKL602B420A_300x.jpg?v=1607944479', NULL),
(73, 'BASIC TROUSER', 'Rs.1,317.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GKB606420A_300x.jpg?v=1609392595', NULL),
(74, 'HOODIE JACKET', 'Rs.1,497.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GHK606D420A_95fba90d-fb70-4503-9650-9556d4b7f311_300x.jpg?v=1608616746', NULL),
(75, 'PAPER BAG JEANS', 'Rs.1,317.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/GDJ615420A_300x.jpg?v=1609392470', NULL),
(76, 'COLOR BLOCK KNITTED  JUMPER', 'Rs.1,917.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BS608420B_300x.jpg?v=1606400858', NULL),
(77, 'DEATH VADER REVENGE TEE F/S', 'Rs.1,017.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BKT602420B_300x.jpg?v=1606401183', NULL),
(78, 'CANVAS LONG HOODED COAT', 'Rs.3,597.00', '//cdn.shopify.com/s/files/1/0281/5970/5228/products/BJ605420_300x.jpg?v=1606401245', NULL),
(79, 'Teal Smocked Top', 'Rs.  1590', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-016.jpg', NULL),
(80, 'Casual Jeans', 'Rs.  1690', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gdb-024.jpg', NULL),
(81, 'Yellow Floral Top', 'Rs.  1090', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-023_1.jpg', NULL),
(82, 'Minnie Mouse T-Shirt', 'Rs.  1090', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-121.jpg', NULL),
(83, 'Striped Shimmer Top', 'Rs.  2190', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-175.jpg', NULL),
(84, 'Ruffled Seashells Top', 'Rs.  1890', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-019.jpg', NULL),
(85, 'Baby Pink Top', 'Rs.  1790', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-018.jpg', NULL),
(86, 'Multi Floral Top', 'Rs.  1290', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-008.jpg', NULL),
(87, 'Printed Hearts Top', 'Rs.  1290', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-foss21-gkt-024.jpg', NULL),
(88, 'Embroidered Flamingo Top', 'Rs.  1290', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gkt-009-_1_.jpg', NULL),
(89, 'Floral Embroidered Jeans', 'Rs.  1990', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gdb-019.jpg', NULL),
(90, 'Floral Wonders Top', 'Rs.  1590', 'https://www.ilovehopscotch.com/media/catalog/product/cache/7e18d6a53b979564d4275b1e496df2c1/h/-/h-ss21-gwt-008.jpg', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kids_cloths`
--
ALTER TABLE `kids_cloths`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kids_cloths`
--
ALTER TABLE `kids_cloths`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
