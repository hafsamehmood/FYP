-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2021 at 08:47 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `python_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `men_shoes`
--

CREATE TABLE `men_shoes` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `image` longtext DEFAULT NULL,
  `brands` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `men_shoes`
--

INSERT INTO `men_shoes` (`id`, `title`, `price`, `image`, `brands`) VALUES
(1, 'Trendy Chappals for Women', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_e11a695d-48f7-4f58-afe5-7850b0a9c53c_300x.jpg?v=1614338390', NULL),
(2, 'Smart Sandals for Men', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_bd65be82-4dcb-4fc1-a38e-d8133602fdab_300x.jpg?v=1612263750', NULL),
(3, 'Abrex Mens Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_0938a6c6-2483-4016-9a98-b46fdfe93ca0_300x.jpg?v=1603365611', NULL),
(4, 'Comfortable Boots for Men', 'Rs.1,799.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/4_3ce4ac1b-1afe-4d72-ad07-40055ae87c20_300x.jpg?v=1605071645', NULL),
(5, 'Studded Comfy Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_9825_73cb2ad9-2b87-4abd-8953-101e8f8954e8_300x.jpg?v=1603363971', NULL),
(6, 'Toe Ring Women Chappal', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_59ae2a7e-4ca8-42e9-b672-0e5307a42f57_300x.jpg?v=1603363636', NULL),
(7, 'Toe Ring Women Chappal', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_e86e8511-2b0a-476e-871a-312fcaf8a17a_300x.jpg?v=1603363627', NULL),
(8, 'Flower Print Girls Chappals', 'Rs.699.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_edfa4bea-482a-46e7-af55-ecbc0244959c_300x.jpg?v=1611733834', NULL),
(9, 'Studded Comfy Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_9831copy_bd606cd0-d2eb-4cf2-ad89-21d2d2e20c22_300x.jpg?v=1603363964', NULL),
(10, 'Women Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_b4cb1a84-109b-4381-a924-8efea17ec78d_300x.jpg?v=1612758881', NULL),
(11, 'Mens Royal Chappals', 'Rs.799.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_ca6a860c-0f49-4ac1-a480-42e2a8adf549_300x.jpg?v=1613024513', NULL),
(12, 'Women Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_155562f6-547b-4ccf-a401-8110866d75a2_300x.jpg?v=1612759094', NULL),
(13, 'Printed Boys Chappals', 'Rs.499.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_ed5ad89e-648d-4cd1-a186-356673d86388_300x.jpg?v=1611053744', NULL),
(14, 'Thong Ladies Chappal', 'Rs.1,299.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/5_3d87b7ab-0994-4f3b-be3c-7845a5257f47_300x.jpg?v=1617279609', NULL),
(15, 'Flower Print Girls Chappals', 'Rs.699.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_d21310e3-1af4-416c-9f60-0afc9d7372fd_300x.jpg?v=1611733923', NULL),
(16, 'Comfortable Boots for Men', 'Rs.1,799.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/5_e60542b5-fb54-4d3c-b3dc-721c76db607f_300x.jpg?v=1610017310', NULL),
(17, 'Casual Flat Chappals', 'Rs.1,199.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_e5363148-13d7-45eb-8993-e4a77fc03766_300x.jpg?v=1616413305', NULL),
(18, 'Printed Boys Chappals', 'Rs.499.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_a2e72d59-6476-4031-9de3-79775acabaa4_300x.jpg?v=1611053670', NULL),
(19, 'Criss Coss Textured Chappal', 'Rs.1,199.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_5a6be223-f509-4853-b124-ab70ca9e8e3f_300x.jpg?v=1612868025', NULL),
(20, 'Mens Sports Shoes', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_2568copy_65ccfc5d-3c2e-4153-9397-6e5d3031df2c_300x.jpg?v=1603361588', NULL),
(21, 'Smart Sandals for Men', 'Rs.1,599.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_171743a6-3a22-46dd-99d5-290b8e12cf5b_300x.jpg?v=1612263718', NULL),
(22, 'Aqua Sandals for Men', 'Rs.1,199.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_1131_85988c52-2fd6-4cb8-b5e8-d228360ee3ee_300x.jpg?v=1603365516', NULL),
(23, 'FLIP FLOP EF-8206', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/files/INSTA_POST_SUMMER_2021_335x500.jpg?v=1614535071', NULL),
(24, 'FLIP FLOP EF-8206', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneA5-3952e46-urban-sole_4f2cc193-1d7a-4ca4-9681-489047feac4f_300x.jpg?v=1602686156', NULL),
(25, 'FLIP FLOP EF-8210', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneS25-7e3c2f6-urban-sole_043eca9c-4914-41ae-a27d-ccfcd72c77e5_300x.jpg?v=1602686156', NULL),
(26, 'FLIP FLOP EF-8210', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneA8-e6f645b-urban-sole_300x.jpg?v=1602755311', NULL),
(27, 'CITRINE BR-9151', 'Rs.899', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneS25-7e3c2f6-urban-sole_043eca9c-4914-41ae-a27d-ccfcd72c77e5_300x.jpg?v=1602686156', NULL),
(28, 'SANDAL 611006', 'Rs.899', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneA12-d87bd5f-urban-sole_42844119-2b27-471c-a6ce-c02084c7fe48_300x.jpg?v=1602686136', NULL),
(29, 'Gloze HXDS', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/GlozeHXDSBlack_42009100272-011_80x.jpg?v=1613644155', NULL),
(30, 'Cordo GTDS', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_3474_80x.jpg?v=1613644617', NULL),
(31, 'Rampik GTFL', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_3507_80x.jpg?v=1613644521', NULL),
(32, 'Vesper HXDS', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/VesperHXDSBlack-009100270-011_80x.jpg?v=1613644957', NULL),
(33, 'SS-HL-0149', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_2415_80x.jpg?v=1614839894', NULL),
(34, 'SS-HL-0152', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/SS-HL-0152Black-009590089-011_80x.jpg?v=1614839663', NULL),
(35, 'SS-HL-0086', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/000300049-479-SS-HL-0086-Red_80x.JPG?v=1542690065', NULL),
(36, 'SS-ML-0005', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009590079-011-SS-ML-0005-Black_80x.jpg?v=1594709537', NULL),
(37, 'HP-KD-CS-015', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9209_80x.jpg?v=1613641098', NULL),
(38, 'HP-KD-CS-016', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9143_80x.jpg?v=1613640844', NULL),
(39, 'HP-KD-SP-014', 'Rs.2,657.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9085_11626a85-17ec-4f01-987f-b661b3e439a7_80x.jpg?v=1613643533', NULL),
(40, 'HP-KD-SP-002', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9129_80x.jpg?v=1613642998', NULL),
(41, 'HP-SS-0005', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9491_80x.jpg?v=1613742651', NULL),
(42, 'HP Brush', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_8321_80x.jpg?v=1614335540', NULL),
(43, 'HP Leather Lotion', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099822-644-01_HP_Leather_Lotion_80x.jpg?v=1541744105', NULL),
(44, 'HP-SS-0003', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9451_80x.jpg?v=1613742343', NULL),
(45, 'Terminal', 'Rs.4,995.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099302-599-Terminal-Dark_Brown_450x.jpg?v=1553509590 1025w', NULL),
(46, 'Madden Out', 'Rs.4,498.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099302-044-Terminal-Navy_450x.jpg?v=1607950162 1025w', NULL),
(47, 'Hocus', 'Rs.6,995.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099394-011_2_450x.jpg?v=1618653223 1025w', NULL),
(48, 'Salub', 'Rs.6,995.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099394-011_3_450x.jpg?v=1618653223 1025w', NULL),
(49, 'Trendy Chappals for Women', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_e11a695d-48f7-4f58-afe5-7850b0a9c53c_300x.jpg?v=1614338390', NULL),
(50, 'Smart Sandals for Men', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_bd65be82-4dcb-4fc1-a38e-d8133602fdab_300x.jpg?v=1612263750', NULL),
(51, 'Abrex Mens Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_0938a6c6-2483-4016-9a98-b46fdfe93ca0_300x.jpg?v=1603365611', NULL),
(52, 'Comfortable Boots for Men', 'Rs.1,799.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/4_3ce4ac1b-1afe-4d72-ad07-40055ae87c20_300x.jpg?v=1605071645', NULL),
(53, 'Studded Comfy Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_9825_73cb2ad9-2b87-4abd-8953-101e8f8954e8_300x.jpg?v=1603363971', NULL),
(54, 'Toe Ring Women Chappal', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_59ae2a7e-4ca8-42e9-b672-0e5307a42f57_300x.jpg?v=1603363636', NULL),
(55, 'Toe Ring Women Chappal', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_e86e8511-2b0a-476e-871a-312fcaf8a17a_300x.jpg?v=1603363627', NULL),
(56, 'Flower Print Girls Chappals', 'Rs.699.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_edfa4bea-482a-46e7-af55-ecbc0244959c_300x.jpg?v=1611733834', NULL),
(57, 'Studded Comfy Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_9831copy_bd606cd0-d2eb-4cf2-ad89-21d2d2e20c22_300x.jpg?v=1603363964', NULL),
(58, 'Women Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_b4cb1a84-109b-4381-a924-8efea17ec78d_300x.jpg?v=1612758881', NULL),
(59, 'Mens Royal Chappals', 'Rs.799.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_ca6a860c-0f49-4ac1-a480-42e2a8adf549_300x.jpg?v=1613024513', NULL),
(60, 'Women Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_155562f6-547b-4ccf-a401-8110866d75a2_300x.jpg?v=1612759094', NULL),
(61, 'Printed Boys Chappals', 'Rs.499.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_ed5ad89e-648d-4cd1-a186-356673d86388_300x.jpg?v=1611053744', NULL),
(62, 'Thong Ladies Chappal', 'Rs.1,299.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/5_3d87b7ab-0994-4f3b-be3c-7845a5257f47_300x.jpg?v=1617279609', NULL),
(63, 'Flower Print Girls Chappals', 'Rs.699.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_d21310e3-1af4-416c-9f60-0afc9d7372fd_300x.jpg?v=1611733923', NULL),
(64, 'Comfortable Boots for Men', 'Rs.1,799.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/5_e60542b5-fb54-4d3c-b3dc-721c76db607f_300x.jpg?v=1610017310', NULL),
(65, 'Casual Flat Chappals', 'Rs.1,199.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_e5363148-13d7-45eb-8993-e4a77fc03766_300x.jpg?v=1616413305', NULL),
(66, 'Printed Boys Chappals', 'Rs.499.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_a2e72d59-6476-4031-9de3-79775acabaa4_300x.jpg?v=1611053670', NULL),
(67, 'Criss Coss Textured Chappal', 'Rs.1,199.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_5a6be223-f509-4853-b124-ab70ca9e8e3f_300x.jpg?v=1612868025', NULL),
(68, 'Mens Sports Shoes', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_2568copy_65ccfc5d-3c2e-4153-9397-6e5d3031df2c_300x.jpg?v=1603361588', NULL),
(69, 'Smart Sandals for Men', 'Rs.1,599.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_171743a6-3a22-46dd-99d5-290b8e12cf5b_300x.jpg?v=1612263718', NULL),
(70, 'Aqua Sandals for Men', 'Rs.1,199.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_1131_85988c52-2fd6-4cb8-b5e8-d228360ee3ee_300x.jpg?v=1603365516', NULL),
(71, 'FLIP FLOP EF-8206', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/files/INSTA_POST_SUMMER_2021_335x500.jpg?v=1614535071', NULL),
(72, 'FLIP FLOP EF-8206', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneA5-3952e46-urban-sole_4f2cc193-1d7a-4ca4-9681-489047feac4f_300x.jpg?v=1602686156', NULL),
(73, 'FLIP FLOP EF-8210', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneS25-7e3c2f6-urban-sole_043eca9c-4914-41ae-a27d-ccfcd72c77e5_300x.jpg?v=1602686156', NULL),
(74, 'FLIP FLOP EF-8210', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneA8-e6f645b-urban-sole_300x.jpg?v=1602755311', NULL),
(75, 'CITRINE BR-9151', 'Rs.899', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneS25-7e3c2f6-urban-sole_043eca9c-4914-41ae-a27d-ccfcd72c77e5_300x.jpg?v=1602686156', NULL),
(76, 'SANDAL 611006', 'Rs.899', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneA12-d87bd5f-urban-sole_42844119-2b27-471c-a6ce-c02084c7fe48_300x.jpg?v=1602686136', NULL),
(77, 'Gloze HXDS', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/GlozeHXDSBlack_42009100272-011_80x.jpg?v=1613644155', NULL),
(78, 'Cordo GTDS', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_3474_80x.jpg?v=1613644617', NULL),
(79, 'Rampik GTFL', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_3507_80x.jpg?v=1613644521', NULL),
(80, 'Vesper HXDS', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/VesperHXDSBlack-009100270-011_80x.jpg?v=1613644957', NULL),
(81, 'SS-HL-0149', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_2415_80x.jpg?v=1614839894', NULL),
(82, 'SS-HL-0152', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/SS-HL-0152Black-009590089-011_80x.jpg?v=1614839663', NULL),
(83, 'SS-HL-0086', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/000300049-479-SS-HL-0086-Red_80x.JPG?v=1542690065', NULL),
(84, 'SS-ML-0005', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009590079-011-SS-ML-0005-Black_80x.jpg?v=1594709537', NULL),
(85, 'HP-KD-CS-015', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9209_80x.jpg?v=1613641098', NULL),
(86, 'HP-KD-CS-016', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9143_80x.jpg?v=1613640844', NULL),
(87, 'HP-KD-SP-014', 'Rs.2,657.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9085_11626a85-17ec-4f01-987f-b661b3e439a7_80x.jpg?v=1613643533', NULL),
(88, 'HP-KD-SP-002', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9129_80x.jpg?v=1613642998', NULL),
(89, 'HP-SS-0005', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9491_80x.jpg?v=1613742651', NULL),
(90, 'HP Brush', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_8321_80x.jpg?v=1614335540', NULL),
(91, 'HP Leather Lotion', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099822-644-01_HP_Leather_Lotion_80x.jpg?v=1541744105', NULL),
(92, 'HP-SS-0003', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9451_80x.jpg?v=1613742343', NULL),
(93, 'Terminal', 'Rs.4,995.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099302-599-Terminal-Dark_Brown_450x.jpg?v=1553509590 1025w', NULL),
(94, 'Madden Out', 'Rs.4,498.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099302-044-Terminal-Navy_450x.jpg?v=1607950162 1025w', NULL),
(95, 'Hocus', 'Rs.6,995.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099394-011_2_450x.jpg?v=1618653223 1025w', NULL),
(96, 'Salub', 'Rs.6,995.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099394-011_3_450x.jpg?v=1618653223 1025w', NULL),
(97, 'Trendy Chappals for Women', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_e11a695d-48f7-4f58-afe5-7850b0a9c53c_300x.jpg?v=1614338390', NULL),
(98, 'Smart Sandals for Men', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_bd65be82-4dcb-4fc1-a38e-d8133602fdab_300x.jpg?v=1612263750', NULL),
(99, 'Abrex Mens Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_0938a6c6-2483-4016-9a98-b46fdfe93ca0_300x.jpg?v=1603365611', NULL),
(100, 'Comfortable Boots for Men', 'Rs.1,799.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/4_3ce4ac1b-1afe-4d72-ad07-40055ae87c20_300x.jpg?v=1605071645', NULL),
(101, 'Studded Comfy Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_9825_73cb2ad9-2b87-4abd-8953-101e8f8954e8_300x.jpg?v=1603363971', NULL),
(102, 'Toe Ring Women Chappal', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_59ae2a7e-4ca8-42e9-b672-0e5307a42f57_300x.jpg?v=1603363636', NULL),
(103, 'Toe Ring Women Chappal', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_e86e8511-2b0a-476e-871a-312fcaf8a17a_300x.jpg?v=1603363627', NULL),
(104, 'Flower Print Girls Chappals', 'Rs.699.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_edfa4bea-482a-46e7-af55-ecbc0244959c_300x.jpg?v=1611733834', NULL),
(105, 'Studded Comfy Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_9831copy_bd606cd0-d2eb-4cf2-ad89-21d2d2e20c22_300x.jpg?v=1603363964', NULL),
(106, 'Women Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_b4cb1a84-109b-4381-a924-8efea17ec78d_300x.jpg?v=1612758881', NULL),
(107, 'Mens Royal Chappals', 'Rs.799.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_ca6a860c-0f49-4ac1-a480-42e2a8adf549_300x.jpg?v=1613024513', NULL),
(108, 'Women Chappals', 'Rs.999.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_155562f6-547b-4ccf-a401-8110866d75a2_300x.jpg?v=1612759094', NULL),
(109, 'Printed Boys Chappals', 'Rs.499.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/3_ed5ad89e-648d-4cd1-a186-356673d86388_300x.jpg?v=1611053744', NULL),
(110, 'Thong Ladies Chappal', 'Rs.1,299.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/5_3d87b7ab-0994-4f3b-be3c-7845a5257f47_300x.jpg?v=1617279609', NULL),
(111, 'Flower Print Girls Chappals', 'Rs.699.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_d21310e3-1af4-416c-9f60-0afc9d7372fd_300x.jpg?v=1611733923', NULL),
(112, 'Comfortable Boots for Men', 'Rs.1,799.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/5_e60542b5-fb54-4d3c-b3dc-721c76db607f_300x.jpg?v=1610017310', NULL),
(113, 'Casual Flat Chappals', 'Rs.1,199.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_e5363148-13d7-45eb-8993-e4a77fc03766_300x.jpg?v=1616413305', NULL),
(114, 'Printed Boys Chappals', 'Rs.499.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_a2e72d59-6476-4031-9de3-79775acabaa4_300x.jpg?v=1611053670', NULL),
(115, 'Criss Coss Textured Chappal', 'Rs.1,199.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_5a6be223-f509-4853-b124-ab70ca9e8e3f_300x.jpg?v=1612868025', NULL),
(116, 'Mens Sports Shoes', 'Rs.1,099.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_2568copy_65ccfc5d-3c2e-4153-9397-6e5d3031df2c_300x.jpg?v=1603361588', NULL),
(117, 'Smart Sandals for Men', 'Rs.1,599.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/2_171743a6-3a22-46dd-99d5-290b8e12cf5b_300x.jpg?v=1612263718', NULL),
(118, 'Aqua Sandals for Men', 'Rs.1,199.00', '//cdn.shopify.com/s/files/1/0371/5416/0772/products/IMG_1131_85988c52-2fd6-4cb8-b5e8-d228360ee3ee_300x.jpg?v=1603365516', NULL),
(119, 'FLIP FLOP EF-8206', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/files/INSTA_POST_SUMMER_2021_335x500.jpg?v=1614535071', NULL),
(120, 'FLIP FLOP EF-8206', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneA5-3952e46-urban-sole_4f2cc193-1d7a-4ca4-9681-489047feac4f_300x.jpg?v=1602686156', NULL),
(121, 'FLIP FLOP EF-8210', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneS25-7e3c2f6-urban-sole_043eca9c-4914-41ae-a27d-ccfcd72c77e5_300x.jpg?v=1602686156', NULL),
(122, 'FLIP FLOP EF-8210', 'Rs.1,199', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneA8-e6f645b-urban-sole_300x.jpg?v=1602755311', NULL),
(123, 'CITRINE BR-9151', 'Rs.899', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneS25-7e3c2f6-urban-sole_043eca9c-4914-41ae-a27d-ccfcd72c77e5_300x.jpg?v=1602686156', NULL),
(124, 'SANDAL 611006', 'Rs.899', '//cdn.shopify.com/s/files/1/0466/9653/0085/products/1665x1110-E-com-JuneA12-d87bd5f-urban-sole_42844119-2b27-471c-a6ce-c02084c7fe48_300x.jpg?v=1602686136', NULL),
(125, 'Gloze HXDS', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/GlozeHXDSBlack_42009100272-011_80x.jpg?v=1613644155', NULL),
(126, 'Cordo GTDS', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_3474_80x.jpg?v=1613644617', NULL),
(127, 'Rampik GTFL', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_3507_80x.jpg?v=1613644521', NULL),
(128, 'Vesper HXDS', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/VesperHXDSBlack-009100270-011_80x.jpg?v=1613644957', NULL),
(129, 'SS-HL-0149', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_2415_80x.jpg?v=1614839894', NULL),
(130, 'SS-HL-0152', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/SS-HL-0152Black-009590089-011_80x.jpg?v=1614839663', NULL),
(131, 'SS-HL-0086', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/000300049-479-SS-HL-0086-Red_80x.JPG?v=1542690065', NULL),
(132, 'SS-ML-0005', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009590079-011-SS-ML-0005-Black_80x.jpg?v=1594709537', NULL),
(133, 'HP-KD-CS-015', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9209_80x.jpg?v=1613641098', NULL),
(134, 'HP-KD-CS-016', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9143_80x.jpg?v=1613640844', NULL),
(135, 'HP-KD-SP-014', 'Rs.2,657.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9085_11626a85-17ec-4f01-987f-b661b3e439a7_80x.jpg?v=1613643533', NULL),
(136, 'HP-KD-SP-002', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9129_80x.jpg?v=1613642998', NULL),
(137, 'HP-SS-0005', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9491_80x.jpg?v=1613742651', NULL),
(138, 'HP Brush', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_8321_80x.jpg?v=1614335540', NULL),
(139, 'HP Leather Lotion', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099822-644-01_HP_Leather_Lotion_80x.jpg?v=1541744105', NULL),
(140, 'HP-SS-0003', '', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/IMG_9451_80x.jpg?v=1613742343', NULL),
(141, 'Terminal', 'Rs.4,995.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099302-599-Terminal-Dark_Brown_450x.jpg?v=1553509590 1025w', NULL),
(142, 'Madden Out', 'Rs.4,498.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099302-044-Terminal-Navy_450x.jpg?v=1607950162 1025w', NULL),
(143, 'Hocus', 'Rs.6,995.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099394-011_2_450x.jpg?v=1618653223 1025w', NULL),
(144, 'Salub', 'Rs.6,995.00', '//cdn.shopify.com/s/files/1/0016/0074/9623/products/009099394-011_3_450x.jpg?v=1618653223 1025w', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `men_shoes`
--
ALTER TABLE `men_shoes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `men_shoes`
--
ALTER TABLE `men_shoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
