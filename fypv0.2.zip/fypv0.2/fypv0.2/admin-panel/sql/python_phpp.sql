-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2021 at 05:42 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `python_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `men_cloths`
--

CREATE TABLE `men_cloths` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `image` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `men_cloths`
--

INSERT INTO `men_cloths` (`id`, `title`, `price`, `image`) VALUES
(1, 'Monotone Band Collar Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111032GRYBLK_2_800x1000_crop_center.jpg?v=1618826773'),
(2, 'Button Down Shirt with Half Sleeves', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111032GRYBLK_3_800x.jpg?v=1618826773'),
(3, 'Monochrome Aqua Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP211036BRNORG_1_800x1000_crop_center.jpg?v=1618814195'),
(4, 'Checkered Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP211036BRNORG_3_800x.jpg?v=1618814209'),
(5, 'Button Down Shirt with Half Sleeves', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111013_800x1000_crop_center.jpg?v=1619608745'),
(6, 'Checkered Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/34_0c3e3f33-2153-4eff-8323-c34eae5530ad_800x.jpg?v=1619608745'),
(7, 'Abstract Print Button Down Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111026_2_800x1000_crop_center.jpg?v=1617096232'),
(8, 'Future Vision Graphic Twill Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111026_3_800x.jpg?v=1617096232'),
(9, 'Checkered Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP211036BLK_2_800x1000_crop_center.jpg?v=1618814312'),
(10, 'Checkered Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP211036BLK_3_800x.jpg?v=1618814312'),
(11, 'Monochrome Shirt with Resort Collar', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111026FRDPRP_4_800x1000_crop_center.jpg?v=1617175249'),
(12, 'Striped Band Collar Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111026FRDPRP_2_800x.jpg?v=1617175249'),
(13, 'Band Collar Button Down Shirt', 'PKR 2,490', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111035_4_800x1000_crop_center.jpg?v=1612504999'),
(14, 'Band Collar Shirt with Flap Pockets', 'PKR 2,490', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111035_7_800x.jpg?v=1612504999'),
(15, 'Western Styled Denim Shirt with Press Buttons', 'PKR 3,490', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP211017WHT_3_800x1000_crop_center.jpg?v=1618814420'),
(16, 'Checkered Shirt', 'PKR 3,490', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP211017WHT_4_800x.jpg?v=1618814420'),
(17, 'Checkered Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111025NVYWHT_4_800x1000_crop_center.jpg?v=1617175486'),
(18, 'Checkered Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111025NVYWHT_2_800x.jpg?v=1617175506'),
(19, 'Two Piece Collar Button Down Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111012NVYWHT_2_de8aa0f2-f0a4-485c-9e36-b41a1d0a9c23_800x1000_crop_center.jpg?v=1613995987'),
(20, 'Checkered Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111012NVYWHT_1_800x.jpg?v=1613995987'),
(21, 'Basic Button Down Shirt', 'PKR 2,290', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111038BLKGRY_2_0e5ad158-e1b1-4bbd-8716-a53e4cbcdd0d_800x1000_crop_center.jpg?v=1614687308'),
(22, 'Basic Button Down Shirt', 'PKR 2,290', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111038BLKGRY_3_800x.jpg?v=1614687308'),
(23, 'Denim Shirt with Press Buttons', 'PKR 2,490', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111007MSTWHT_3_800x1000_crop_center.jpg?v=1615527432'),
(24, 'Band Collar Button Down Shirt', 'PKR 2,490', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111007MSTWHT_4_800x.jpg?v=1615527432'),
(25, 'Button Down Shirt with Patch Pockets', 'PKR 2,290', '//cdn.shopify.com/s/files/1/2290/7887/products/Men-E-Comm-31_800x1000_crop_center.jpg?v=1617964142'),
(26, 'Band Collar Button Down Shirt', 'PKR 2,290', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111006_3_4839be34-7ce7-40e4-b431-7c755068c523_800x.jpg?v=1617964142'),
(27, 'Denim Shirt with Press Buttons', 'PKR 2,490', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111005BLK_4_800x1000_crop_center.jpg?v=1612505148'),
(28, 'Button Down Shirt with Flap Pockets', 'PKR 2,490', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111005BLK_5_800x.jpg?v=1612505148'),
(29, 'Checkered Shirt', 'PKR 3,290', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP211014MIDBLU_2_800x1000_crop_center.jpg?v=1619829214'),
(30, 'Band Collar Button Down Shirt', 'PKR 3,290', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP211014MIDBLU_1_800x.jpg?v=1619829214'),
(31, 'Western Styled Denim Shirt with Press Buttons', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111021ORGWHT_800x1000_crop_center.jpg?v=1614246170'),
(32, 'Regular Button Down Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111023NVYBUR_2_800x1000_crop_center.jpg?v=1614752851'),
(33, 'Abstract Print Button Down Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111023NVYBUR_3_65ff246e-ba04-4440-8831-85fe95354358_800x.jpg?v=1614752851'),
(34, 'Checkered Button Down Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111021NVYWHT_7_800x1000_crop_center.jpg?v=1614246189'),
(35, 'Checkered Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111021NVYWHT_5_800x.jpg?v=1614246189'),
(36, 'Checkered Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111043BLK_2_800x1000_crop_center.jpg?v=1615377545'),
(37, 'Thumbs Up Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111043BLK_1_800x.jpg?v=1615377545'),
(38, 'Checkered Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/Men-E-Comm-28_800x1000_crop_center.jpg?v=1617964659'),
(39, 'Denim Shirt with Flap Pockets', 'PKR 3,290', '//cdn.shopify.com/s/files/1/2290/7887/products/58_ac4624da-ca95-4ce2-b7a1-16772dcac3c2_800x.jpg?v=1617964659'),
(40, 'Band Collar Shirt with Flap Pockets', 'PKR 3,290', '//cdn.shopify.com/s/files/1/2290/7887/products/MTC111001WHT_1_800x1000_crop_center.jpg?v=1615530053'),
(41, 'Full Sleeves Checkered Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTC111001WHT_3_800x.jpg?v=1615530053'),
(42, 'Button Down Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTC111001BLK_4_800x1000_crop_center.jpg?v=1615453461'),
(43, 'Western Style Denim Shirt with Flap Pockets', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTC111001BLK_2_ea04d844-e41a-47cc-afc0-9d508177bffb_800x.jpg?v=1615453461'),
(44, 'Denim Shirt with Paint Splatter', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111010LT.BLU_1_800x1000_crop_center.jpg?v=1614441889'),
(45, 'Striped Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTF111010LT.BLU_2_800x.jpg?v=1614441889'),
(46, 'Brush Stroked Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111045BLK_3_800x1000_crop_center.jpg?v=1615377089'),
(47, 'Button Down Band Collar Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTP111045BLK_1_800x.jpg?v=1615377089'),
(48, 'Checkered Shirt', 'PKR 2,690', '//cdn.shopify.com/s/files/1/2290/7887/products/MTC111008STN_4_5e5b664e-58ee-42df-8f80-d0be3e74836c_800x1000_crop_center.jpg?v=1624802715'),
(49, 'Denim Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/MTC111008STN_5_800x.jpg?v=1624802725'),
(50, 'Checkered Shirt', 'PKR 2,890', '//cdn.shopify.com/s/files/1/2290/7887/products/86_021084fa-57de-45be-b237-249715760867_800x1000_crop_center.jpg?v=1618226894'),
(51, 'JJKS-S-36810/S21/JJ7025-PN', 'PKR5,490.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(52, 'JJKS-S-36807/S21/JJ7115-PN', 'PKR5,890.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(53, 'JJKS-S-36808/S21/JJ6863-EX', 'PKR6,290.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(54, 'JJKS-S-32490/S21/JJ6886-EX', 'PKR6,390.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(55, 'JJKS-A-34062/S21/JJ7195-FL', 'PKR6,290.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(56, 'JJKS-S-36803/S21/JJ7025-PN', 'PKR5,490.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(57, 'JJKS-S-36802/S21/JJ7025-PN', 'PKR5,490.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(58, 'JJKS-S-34061/S21/JJ6888-EX', 'PKR6,790.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(59, 'JJKS-S-36795/S21/JJ6888-PL', 'PKR6,190.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(60, 'JJKS-S-32488/S21/JJ7115-CL', 'PKR6,390.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(61, 'JJKS-S-34006/S21/JJ6285', 'PKR5,990.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(62, 'JJKS-S-36804/S21/JJ6888-EX', 'PKR7,290.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(63, 'JJKS-A-36753/S21/JJ6949', 'PKR4,890.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(64, 'JJKS-S-36794/S21/JJ6888-PL', 'PKR6,190.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif'),
(65, 'JJKS-S-32492/S21/JJ6886-EX', 'PKR5,490.00', 'https://www.junaidjamshed.com/static/version1624615719/frontend/Rltsquare/junaidjamshed/en_US/WeltPixel_LazyLoading/images/Loader.gif');


--
-- Indexes for dumped tables
--

--
-- Indexes for table `men_cloths`
--
ALTER TABLE `men_cloths`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `men_cloths`
--
ALTER TABLE `men_cloths`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=976;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
