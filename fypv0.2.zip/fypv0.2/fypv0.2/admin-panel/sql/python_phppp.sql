-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2021 at 05:42 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `python_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `women_shoes`
--

CREATE TABLE `women_shoes` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `image` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `women_shoes`
--

INSERT INTO `women_shoes` (`id`, `title`, `price`, `image`) VALUES
(1, '008100687', 'PKR 1,500.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/008100687-blue_4.jpg'),
(2, '008100668', 'PKR 2,150.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/008100668-camel_4.jpg'),
(3, '007000027', 'PKR 1,800.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/007000027-blue_4.jpg'),
(4, '005900296', 'PKR 2,850.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005900296-black_4.jpg'),
(5, '005900287', 'PKR 1,800.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005900287-light-brown_4.jpg'),
(6, '005900257', 'PKR 2,650.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005900257-blue_7.jpg'),
(7, '005800257', 'PKR 1,500.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005800257-maroon_4.jpg'),
(8, '005800232', 'PKR 2,250.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005800232-champagne_4.jpg'),
(9, '005800227', 'PKR 2,500.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005800227-black_4.jpg'),
(10, '005700125', 'PKR 4,150.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005700125-black_4.jpg'),
(11, '005700124', 'PKR 1,400.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005700124-black_4.jpg'),
(12, '005600327', 'PKR 2,090.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005600327-black_4.jpg'),
(13, '005600317', 'PKR 1,400.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/005600317-golden_4.jpg'),
(14, '004200388', 'PKR 2,250.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/004200388-golden_4.jpg'),
(15, '004200383', 'PKR 2,000.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/004200383-golden_4.jpg'),
(16, '004200382', 'PKR 2,950.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/004200382-golden_4.jpg'),
(17, '004200370', 'PKR 2,200.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/004200370-fawn_4.jpg'),
(18, '003400067', 'PKR 3,250.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003400067-light-pink_4.jpg'),
(19, '003400060', 'PKR 1,600.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003400060-black_4.jpg'),
(20, '003300095', 'PKR 2,590.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003300095-blue_4.jpg'),
(21, '003300094', 'PKR 1,600.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003300094-maroon_7.jpg'),
(22, '003300050', 'PKR 2,450.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003300050-blue_5.jpg'),
(23, '003100435', 'PKR 1,300.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003100435-light-brown_4.jpg'),
(24, '003100434', 'PKR 1,890.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003100434-light-brown_4.jpg'),
(25, '003100433', 'PKR 1,600.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003100433-pink_4.jpg'),
(26, '003100423', 'PKR 2,290.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003100423-blue_4.jpg'),
(27, '003100421', 'PKR 1,200.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003100421-black_4.jpg'),
(28, '003100411', 'PKR 1,950.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003100411-black-maroon_4.jpg'),
(29, '003100376', 'PKR 1,200.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003100376-black_4.jpg'),
(30, '003100374', 'PKR 1,890.00', 'https://shopecs.com/pub/media/catalog/product/cache/697d0fdda2d0e47230b8c280462057ca/0/0/003100374-fawn_4.jpg'),
(31, 'Maroon Color Fancy Sandals FN4772', 'Rs.3,000', '//cdn.shopify.com/s/files/1/0485/1459/7030/products/FN477205_3_100x.jpg?v=1622182142'),
(32, 'Golden Color Fancy Sandals FN4752', 'Rs.3,800', '//cdn.shopify.com/s/files/1/0485/1459/7030/t/7/assets/spacer.png?v=9033184019838578881'),
(33, 'Black Color Fancy Sandals FN4750', 'Rs.3,500', '//cdn.shopify.com/s/files/1/0485/1459/7030/t/7/assets/spacer.png?v=9033184019838578881'),
(34, 'Golden Color Fancy Sandals FN4729', 'Rs.3,800', '//cdn.shopify.com/s/files/1/0485/1459/7030/products/FN475215_3_100x.jpg?v=1622182128'),
(35, 'Maroon Color Fancy Sandals FN4715', 'Rs.3,000', '//cdn.shopify.com/s/files/1/0485/1459/7030/t/7/assets/spacer.png?v=9033184019838578881'),
(36, 'Silver Color Fancy Sandals FN4632', 'Rs.3,000', '//cdn.shopify.com/s/files/1/0485/1459/7030/t/7/assets/spacer.png?v=9033184019838578881'),
(37, 'Golden Color Fancy Sandals FN4697', 'Rs.3,000', '//cdn.shopify.com/s/files/1/0485/1459/7030/products/FN475001_3_100x.jpg?v=1622182123'),
(38, 'Golden Color Fancy Sandals FN4757', 'Rs.3,000', '//cdn.shopify.com/s/files/1/0485/1459/7030/t/7/assets/spacer.png?v=9033184019838578881'),
(39, 'Golden Color Fancy Sandals FN4586', 'Rs.3,450', '//cdn.shopify.com/s/files/1/0485/1459/7030/t/7/assets/spacer.png?v=9033184019838578881');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `women_shoes`
--
ALTER TABLE `women_shoes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `women_shoes`
--
ALTER TABLE `women_shoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=430;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
