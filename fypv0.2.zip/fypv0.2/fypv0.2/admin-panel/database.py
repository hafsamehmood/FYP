import pandas as pd
import mysql.connector

db = mysql.connector.connect(user = 'root' , database = 'python_php')
cursor = db.cursor()

query = "select id , title, link , price , oldprice from kids_cloths"
cursor.execute(query)

myAllData = cursor.fetchall()

all_id = []
all_title = []
all_link =[]
all_price = []
all_oldprice = []

for id, title, link, price, oldprice in myAllData:
    all_id.append(id)
    all_title.append(title)
    all_link.append(link)
    all_price.append(price)
    all_oldprice.append(oldprice)

#store data now

dic = {'id' : all_id , 'title' : all_title , 'link' : all_link , 'price' : all_price , 'oldprice' : all_oldprice }

df = pd.DataFrame(dic)

df_csv = df.to_csv('D:/Kids_cloths.csv')









# import pyodbc
#
# conn = pyodbc.connect('Driver={SQL Server};'
#                       'Server=server_name;'
#                       'Database=python_php;'
#                       'Trusted_Connection=yes;')
#
# cursor = conn.cursor()
# cursor.execute('SELECT * FROM table_name')
#
# for i in cursor:
#     print(i)