<?php
    session_start();
    if (isset($_SESSION['adminLogined'])) {
        header('Location: /admin-panel/admin/dashboard.php');
    }
    else
    {
        header('Location: /admin-panel/admin/signIn.php');
    }
?>