<?php
    
    $filename = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']); // getting file name from current URL
?>

<nav class="col-md-2 d-none d-md-block bg-light sidebar">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php if ($filename == "dashboard.php") { ?> active <?php }  ?>"
                    href="/admin-panel/admin/dashboard.php">
                    <span data-feather="home"></span>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if ($filename == "women_cloths.php") { ?> active <?php }  ?>"
                    href="/admin-panel/admin/modules/women_cloths.php">
                    <span data-feather="file"></span>
                    Women Cloths
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php if ($filename == "men_cloths.php") { ?> active <?php }  ?>"
                    href="/admin-panel/admin/modules/men_cloths.php">
                    <span data-feather="file"></span>
                    Men Cloths
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php if ($filename == "women_shoes.php") { ?> active <?php }  ?>"
                    href="/admin-panel/admin/modules/women_shoes.php">
                    <span data-feather="file"></span>
                    Women shoes
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php if ($filename == "men_shoes.php") { ?> active <?php }  ?>"
                    href="/admin-panel/admin/modules/men_shoes.php">
                    <span data-feather="file"></span>
                    Men shoes
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php if ($filename == "kids_cloths.php") { ?> active <?php }  ?>"
                    href="/admin-panel/admin/modules/kids_cloths.php">
                    <span data-feather="file"></span>
                    Kids Cloths
                </a>
            </li>

        </ul>

        <!-- <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Saved reports</span>
            <a class="d-flex align-items-center text-muted" href="#">
                <span data-feather="plus-circle"></span>
            </a>
        </h6>
        <ul class="nav flex-column mb-2">
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <span data-feather="file-text"></span>
                    Current month
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <span data-feather="file-text"></span>
                    Last quarter
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <span data-feather="file-text"></span>
                    Social engagement
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <span data-feather="file-text"></span>
                    Year-end sale
                </a>
            </li>
        </ul> -->
    </div>
</nav>