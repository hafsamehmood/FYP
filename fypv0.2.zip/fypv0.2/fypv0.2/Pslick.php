<html>
  <head>
  <title>My Now Amazing Webpage</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="BootStrap Files/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
</head>
  <body class="bg-dark">

  <div class="container your-class ">
    <div class="row slider"> 
        <div class="col-lg-3 col-md-3 col-12">
            <div class="card text-center" style="width: 12rem; height: 18rem;">
                <img src="BootStrap Files/Mens Shoes/p2.jpg" class="card-img-top " height="170px" width="170px"  alt="...">
                <div class="card-body">
                    <h2>Sneakers</h2>
               <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
                </div>
              </div>
    </div>

        <div class="col-lg-3 col-md-3 col-12">
            <div class="card text-center" style="width: 12rem; height: 18rem;">
                <img src="BootStrap Files/Mens Shoes/p2.jpg" class="card-img-top " height="170px" width="170px"  alt="...">
                <div class="card-body">
                    <h2>Sneakers</h2>
               <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
                </div>
              </div>
    </div>

        <div class="col-lg-3 col-md-3 col-12">
            <div class="card text-center" style="width: 12rem; height: 18rem;">
                <img src="BootStrap Files/Mens Shoes/p2.jpg" class="card-img-top " height="170px" width="170px"  alt="...">
                <div class="card-body">
                    <h2>Sneakers</h2>
               <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
                </div>
              </div>
    </div>
    <div class="col-lg-3 col-md-3 col-12">
      <div class="card text-center" style="width: 12rem; height: 18rem;">
          <img src="BootStrap Files/Mens Shoes/p2.jpg" class="card-img-top " height="170px" width="170px"  alt="...">
          <div class="card-body">
              <h2>Sneakers</h2>
         <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
          </div>
        </div>
</div>
   

  </div>
  </div>
</div>
  <script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
  <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
  <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous"></script>  
<script >

$('.slider').slick({
  infinite: true,
  slidesToShow: 3,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 1000,
});
</script>
</body>
</html>
				