function getBotResponse(input) {
  
    // Simple responses
    if (input == "hi" || input == "hello") {
        return "Hello Mubashir How may I help You!";
    } else if (input == "goodbye" || input =="ok" ||  input =="OK") {
        return " Nice to meet U Talk to you later!";
    } 
    else if (input == "Ndure" || input =="ndure" ||  input =="NDURE") {
        return "We Have NDURE BRAND";
    }
    else
    {
        return "jjadhaj";
    }
   
}