<!DOCTYPE html>
<html lang="en">
<?php include('header.php'); ?>
<?php include('dbh.php'); ?>
<body>
    <!-- Header Start -->
    <div class="header-part">
        
        <?php include('navBar.php'); ?>

        <!--Subscribe Section Start-->
        <div class="container bg-dark">
            <div class="row">
                    <?php
                        if (isset($_GET['category'])) {
                            $dataAppend = '';
                            if (isset($_GET['brand'])) {
                                $sql = 'SELECT * FROM '.$_GET['category'].' WHERE brand = "'.$_GET['brand'].'"';
                                $result = mysqli_query($con,$sql);
                                while($row = mysqli_fetch_array($result)) {
                                    if ($_GET['brand'] == $row['brand']) {
                                        $dataAppend .= '<div class="col-md-4 p-2">
                                        
                                            <div class="card mb-4 box-shadow">
                                            <a href = "'.$row['link'].'" target="_blank">
                                            <img class="card-img-top"
                                            src="'.$row['image'].'"
                                            alt="Card image cap">
                                            </a>
                                                    <div class="card-body">
                                                    <p class="card-text">'.$row['title'].'</p>
                                                    <div class="d-flex justify-content-between align-items-center">
                                                    <h5 class="card-title"><strike class="text-muted h6">'.$row['oldprice'].'</strike>
                                                    <h4 class="text-muted">'.$row['price'].'</h4>
                                                    </div>


                                                </div>
                                            </div>
                                        </div>';
                                    }
                                    
                                }
                            }

                            echo $dataAppend;
                            // else
                            // {
                            //     $sql = 'SELECT * FROM '.$_GET['category'];
                            // }
                        }
                    ?>

            </div>
        </div>
        <!--Subscribe Section Start-->
        <?php include('footer.php'); ?>



</body>

</html>