<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>WomensUnstiched/COSTCUTTERS.com</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="BootStrap Files/bootstrap.min.css">
<link rel="stylesheet" href="WomensUnstiched.css">
<!--  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
<!--  -->
</head>

<body>
<!-- Header Start -->
<div class="header-part">
  <!-- NavBar Start -->
  <!-- NavBar Start -->
  <?php include('navBar.php'); ?>
    <!-- NavBar Ends -->


</div>
<div class="row">
<div class="col-12">
<img src="BootStrap Files/Womens Unstiched/bg-1.jpg" width="100%" class="img-fluid" >
</div>
</div>
<!-- Lagcy Continues -->
<h1 class="selling-header text-center bg-dark">Choose Your Own Style</h1>
<!-- Slider Start -->
<div class="container-fluid ">
    <div class="site-slider-2">
    <div class="row slider-2 text-center">
       <div class="col-lg-2 col-md-2 col-12 ">
        <div class="card text-center" style="width: 14rem; height: 18rem;">
            <img src="BootStrap Files/Womens Unstiched/p-1.jpg" class="card-img-top " height="170px" width="170px"  alt="...">
            <div class="card-body">
                <h2>Light Grey</h2>
           <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
            </div>
          </div>
       </div>


       <div class="col-lg-2 col-md-2 col-12">
        <div class="card text-center" style="width: 14rem; height: 18rem;">
            <img src="BootStrap Files/Womens Unstiched/p-2.jpg" class="card-img-top " height="170px" width="170px" alt="...">
            <div class="card-body">
                <h2>Blue & Red</h2>
           <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
            </div>
          </div>
       </div>


       <div class="col-lg-2 col-md-2 col-12">
        <div class="card text-center" style="width: 14rem; height: 18rem;">
            <img src="BootStrap Files/Womens Unstiched/p-3.jpg" class="card-img-top " height="170px" width="170px" alt="...">
            <div class="card-body">
                <h2>yellow Style</h2>
           <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
            </div>
          </div>
       </div>



       <div class="col-lg-2 col-md-2 col-12">
        <div class="card text-center" style="width: 14rem; height:18rem;">
            <img src="BootStrap Files/Womens Unstiched/p-4.jpg" class="card-img-top " height="170px" width="170px"  alt="...">
            <div class="card-body">
                <h2>Dark Blue</h2>
           <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
            </div>
          </div>
       </div>

       <div class="col-lg-2 col-md-2 col-12">
        <div class="card text-center" style="width: 14rem; height: 18rem;">
            <img src="BootStrap Files/Womens Unstiched/p-5.jpg" class="card-img-top " height="170px" width="170px"  alt="...">
            <div class="card-body">
                <h2>Aqua Style</h2>
           <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
            </div>
          </div>
       </div>

       <div class="col-lg-2 col-md-2 col-12">
        <div class="card text-center" style="width: 14rem; height: 18rem;">
            <img src="BootStrap Files/Womens Unstiched/p-6.jpg" class="card-img-top " height="170px" width="170px"  alt="...">
            <div class="card-body">
                <h2>New Design</h2>
           <a href="#"><h5 class="btn btn-warning">Buy Now</h5></a>
            </div>
          </div>
       </div>
    </div>

</div>
</div>

    <!-- Slider End -->
<!-- Selling Area -->
<h1 class="selling-header text-center bg-dark">WOMEN UNSTICHED</h1>
<div class="container-fluid selling-area">
<div class="row selling-cards">
<div class="col-lg-3 col-md-3 col-sm-6">
    <div class="card" style="width: 18rem; height: 450px;">
        <img src="BootStrap Files/Womens Unstiched/p-8.jpg" class="card-img-top" height="250px" >
        <h2><span class="badge badge-danger">HOT</span></h2>
        <div class="card-body text-center">
          <h4 class="product-title">Designer Dress</h4>
          <h3 class="product-price">RS:3500/-</h3>
<div class="rattings">
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star"></span><br>
</div>
          <a href="#" class="btn btn-warning">Add to Cart</a>
        </div>
      </div>
</div>
<!--  -->
<div class="col-lg-3 col-md-3 col-sm-6">
    <div class="card" style="width: 18rem; height: 450px;">
        <img src="BootStrap Files//Womens Unstiched/p-7.jpg" class="card-img-top " height="250px">
        <h2><span class="badge badge-danger">HOT</span></h2>
        <div class="card-body text-center">
          <h4 class="product-title">Shinny Grey</h4>
          <h3 class="product-price">RS:3000/-</h3>
<div class="rattings">
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star"></span><br>
</div>
          <a href="#" class="btn btn-warning">Add to Cart</a>
        </div>
      </div>
</div>
<!--  -->
<div class="col-lg-3 col-md-3 col-sm-6">
    <div class="card" style="width: 18rem; height: 450px;">
        <img src="BootStrap Files/Womens Unstiched/p-1.jpg" class="card-img-top img-fluid" height="300px">
        <h2><span class="badge badge-warning">Limited</span></h2>
        <div class="card-body text-center">
          <h4 class="product-title">Mehroon</h4>
          <h3 class="product-price">RS:2500/-</h3>
<div class="rattings">
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star"></span><br>
</div>
          <a href="#" class="btn btn-warning">Add to Cart</a>
        </div>
      </div>
</div>
<!--  -->

<div class="col-lg-3 col-md-3 col-sm-6">
    <div class="card" style="width: 18rem; height: 450px;">
        <img src="BootStrap Files/Womens Unstiched/p-2.jpg" class="card-img-top " height="300px">
        <h2><span class="badge badge-success">50% OFF</span></h2>
        <div class="card-body text-center">
          <h4 class="product-title">Shinny Brown</h4>
          <h3 class="product-price">RS:1500/-</h3>
<div class="rattings">
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star"></span><br>
</div>
          <a href="#" class="btn btn-warning">Add to Cart</a>
        </div>
      </div>
</div>
<!--  -->
</div>

<!-- Second row Start -->
<div class="row selling-cards">
  <div class="col-lg-3 col-md-3 col-sm-6">
    <div class="card" style="width: 18rem; height: 450px;">
        <img src="BootStrap Files/Womens Unstiched/p-3.jpg" class="card-img-top " height="250px">
        <h2><span class="badge badge-danger">New</span></h2>
        <div class="card-body text-center">
          <h4 class="product-title">Dark Blue</h4>
          <h3 class="product-price">RS:3000/-</h3>
<div class="rattings">
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star"></span><br>
</div>
          <a href="#" class="btn btn-warning">Add to Cart</a>
        </div>
      </div>
</div>
    <!--  -->
    <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="card" style="width: 18rem; height: 450px;">
            <img src="BootStrap Files/Womens Unstiched/p-4.jpg" class="card-img-top" height="250px">
            <h2><span class="badge badge-warning">New</span></h2>
            <div class="card-body text-center">
              <h4 class="product-title">Mehroon</h4>
              <h3 class="product-price">RS:3000/-</h3>
    <div class="rattings">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span><br>
    </div>
              <a href="#" class="btn btn-warning">Add to Cart</a>
            </div>
          </div>
    </div>
    <!--  -->
    <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="card" style="width: 18rem; height: 450px;">
            <img src="BootStrap Files/Womens Unstiched/p-5.jpg" class="card-img-top" height="250px">
            <h2><span class="badge badge-warning">Limited</span></h2>
            
            <div class="card-body text-center">
              <h4 class="product-title">Aqua Style</h4>
              <h3 class="product-price">RS:45000/-</h3>
    <div class="rattings">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span><br>
    </div>
              <a href="#" class="btn btn-warning">Add to Cart</a>
            </div>
          
        </div>
    </div>
    <!--  -->
    
    <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="card" style="width: 18rem; height: 450px;">
            <img src="BootStrap Files/Womens Unstiched/p-2.jpg" class="card-img-top" height="250px">
            <h2><span class="badge badge-success">50% OFF</span></h2>
            <div class="card-body text-center">
              <h4 class="product-title">Shinny Brown</h4>
              <h3 class="product-price">RS:1500/-</h3>
    <div class="rattings">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span><br>
    </div>
              <a href="#" class="btn btn-warning">Add to Cart</a>
            </div>
          </div>
    </div>
    <!--  -->
    </div>
<!-- 2nd row Ends -->

<!-- 3rd row   -->

<div class="row selling-cards">
    <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="card" style="width: 18rem; height: 450px;">
            <img src="BootStrap Files/Womens Unstiched/p-8.jpg" class="card-img-top" height="250px" >
            <h2><span class="badge badge-danger">HOT</span></h2>
            <div class="card-body text-center">
              <h4 class="product-title">DArk Mehroon</h4>
              <h3 class="product-price">RS:2500/-</h3>
    <div class="rattings">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span><br>
    </div>
              <a href="#" class="btn btn-warning">Add to Cart</a>
            </div>
          </div>
    </div>
    <!--  -->
    <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="card" style="width: 18rem; height: 450px;">
            <img src="BootStrap Files/Womens Unstiched/p-1.jpg" class="card-img-top" height="230px">
            <h2><span class="badge badge-primary">New</span></h2>
            <div class="card-body text-center">
              <h4 class="product-title">Sea Green</h4>
              <h3 class="product-price">RS:3000/-</h3>
    <div class="rattings">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span><br>
    </div>
              <a href="#" class="btn btn-warning">Add to Cart</a>
            </div>
          </div>
    </div>
    <!--  -->
    <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="card" style="width: 18rem; height: 450px;">
            <img src="BootStrap Files/Womens Unstiched/p-7.jpg" class="card-img-top" height="250px">
            <h2><span class="badge badge-warning">Limited</span></h2>
            <div class="card-body text-center">
              <h4 class="product-title">Light Grey</h4>
              <h3 class="product-price">RS:45000/-</h3>
    <div class="rattings">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span><br>
    </div>
              <a href="#" class="btn btn-warning">Add to Cart</a>
            </div>
          </div>
    </div>
    <!--  -->
    
    <div class="col-lg-3 col-md-3 col-sm-6">
        <div class="card" style="width: 18rem; height: 450px;">
            <img src="BootStrap Files/Womens Unstiched/p-6.jpg" class="card-img-top" height="250px">
            <h2><span class="badge badge-success">50% OFF</span></h2>
            <div class="card-body text-center">
              <h4 class="product-title">Shinny Grey</h4>
              <h3 class="product-price">RS:1500/-</h3>
    <div class="rattings">
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star"></span><br>
    </div>
              <a href="#" class="btn btn-warning">Add to Cart</a>
            </div>
          </div>
    </div>
    <!--  -->
    </div>

<!-- 3rd row End   -->
</div>
<!-- Selling Area Ends -->
<!--Subscribe Section Start-->
<div class="subs-section bg-dark">
    <div class="row">
    <div class="col-12">
    <h1>Join <span class="cc"> COST CUTTERS </span> Family</h1>
    <p class="text-center">If you want to recieve  daily deals <br>  packges  discounts emails then <br> Please subscribe.</p>
    <div class="box">
    <form >
    <input type="text"  class="input subs-email" name="" id="" placeholder="Your Email...">
    <input type="submit" value="Subscribe" class="input subs-img  ">
    </div>
    </div>
    </div>
    </div>
    <!--Subscribe Section Start-->
<!-- Footer -->
<div class="footer-section">
    <div class="row"> 
    <div class="col-lg-3 col-md-3 col-12">
    <h6>Help</h6>
    <ul>
      <li>Store Location</li>
      <li>Click & Collect</li>
      <li>Deleviery & Returns</li>
      <li>Shipment Details</li>
      <li>Technical Support</li>
      <li>Contact us</li>
      <li>FAQs</li>
    </ul>
    </div>
    
    <div class="col-lg-3 col-md-3 col-12">
    <h6>About</h6>
    <ul>
    <li>Store Location</li>
    <li>Click & Collect</li>
    <li>Deleviery & Returns</li>
    <li>Shipment Details</li>
    <li>Technical Support</li>
    <li>Contact us</li>
    <li>FAQs</li>
    </ul>
    </div>
    
    <div class="col-lg-3 col-md-3 col-12">
    <h6>Resources</h6>
    <ul>
    <li>Store Location</li>
    <li>Click & Collect</li>
    <li>Deleviery & Returns</li>
    <li>Shipment Details</li>
    <li>Technical Support</li>
    <li>Contact us</li>
    <li>FAQs</li>
    </ul>
    </div>
    
    <div class="col-lg-3 col-md-3 col-12">
    <h6>Legal</h6>
    <ul>
    <li>Store Location</li>
    <li>Click & Collect</li>
    <li>Deleviery & Returns</li>
    <li>Shipment Details</li>
    <li>Technical Support</li>
    <li>Contact us</li>
    <li>FAQs</li>
    </ul>
    </div>
    </div>
    </div>
    <div class="social-icons bg-dark">
    <div class="container">
    <h1>JOIN US  ON SOCIAL MEDIA  </h1>
    <a href="#" class="fa fa fa-facebook"></a>
    <a href="#" class="fa fa-google"></a>
    <a href="#" class="fa fa-youtube"></a>
    <a href="#" class="fa fa-instagram"></a>
    <p>&#169 2020 <span style="color:yellow"> COST CUTTERS </span> all rights reserved</p>
    <a href="#"><img src="BootStrap Files/img/Subsarrow-removebg-preview.png" class="fixed-btn" height="50px" width="50px"></a>
    </div>
    </div>
<!-- Footer Ends -->
<script src="BootStrap Files/jquery.slim.min.js"></script>
<script src="BootStrap Files/popper.min.js"></script>
<script src="BootStrap Files/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous"></script>

<script >
    $('.slider-2').slick({
  dots: true,
  infinite: true,
  autoplay:true,
  autoplayspeed:3000,
  speed: 300,
  slidesToShow: 5,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
    </script>
</body>
</html>