<?php include('dbh.php'); ?>
<?php
session_start();
$dataAppend ='';
	if (isset($_SESSION['searchRes'])) {
		$d = json_decode($_SESSION['searchRes']);
		

		$dataAppend .= '<div class="row">';

		for ($i=0; $i < count($d); $i++) { 
			
			$dataAppend .= '
			<div class="col">
				<div class="card" style="width: 18rem;">
				<a href = "'.$d[$i]->href.'" target="_blank">
				<img class="card-img-top" src="'.$d[$i]->image.'" alt="Card image cap">
				</a>

				<div class="card-body">
					<h3 class="card-title">'.$d[$i]->title.'</h3>
					<h5 class="card-title"><strike class="text-muted h6">'.$d[$i]->oldprice.'</strike> '.$d[$i]->price.'</h5>
					<p class="card-title text-bold text-muted">'.$d[$i]->brand.'</p>
				</div>

			    </div>
				
			</div>';
		}
		$dataAppend .= '</div>';

	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<title>Searched Products</title>

<link rel="stylesheet" href="static/css/chat.css">
  <!-- <link rel="stylesheet" href="static/css/home.css">  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="BootStrap Files/bootstrap.min.css">
  <link rel="stylesheet" href="Home.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <script type="text/javascript" src="https://code.jquery.com/jquery-1.8.2.js"></script>


</head>

	<body>
		<!-- <h1>Displaying results</h1> -->
		<div class="header-part">
        
        <?php include('navBar.php'); ?>
		<?php echo $dataAppend;?>
</div>
		
	<
	</body>
</html>