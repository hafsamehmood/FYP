def indexExistInArray(index, arry):
    try:
        t = arry[index]
        return True
    except IndexError:
        return False
