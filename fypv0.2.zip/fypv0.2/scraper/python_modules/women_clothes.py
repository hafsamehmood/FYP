import requests
from bs4 import BeautifulSoup
from python_modules.globalFunctions import *

headers = {
    "User-agent": 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}


def findString(haystack, needle):
    if haystack.find(needle) != -1:
        return True
    return False


def khaadi():
    url = "https://pk.khaadi.com/sale.html?cat=1390%2C3445&product_list_order=discount_p"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.select('.product-item-link')
    sc_Oldprice = soup.select("span[data-price-type='oldPrice'] .price")
    sc_Newprice = soup.select("span[data-price-type='finalPrice'] .price")
    sc_img = soup.select(".product-image-photo:first-child")

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://pk.khaadi.com/"+sc_titles[index]['href']

        oldprice = sc_Oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_Oldprice) else '0 PKR'
        price = sc_Newprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_Newprice) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'price': price,
                'image': img,
                'href': link,
                'brand': 'Khaadi'
            }
        )
    # print(liste)
    return liste
# khaadi()


def sana_safina():
    url = "https://www.sanasafinaz.com/pk/sale/unstitched-fabric.html?product_list_dir=desc"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.select('.product-item-link')
    sc_Oldprice = soup.select("span[data-price-type='oldPrice'] .price")
    sc_Newprice = soup.select("span[data-price-type='finalPrice'] .price")
    sc_img = soup.select(".product-item-photo img:first-child")

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://www.sanasafinaz.com.pk/"+sc_titles[index]['href']

        oldprice = sc_Oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_Oldprice) else '0 PKR'
        price = sc_Newprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_Newprice) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'price': price,
                'image': img,
                'href': link,
                'brand': 'Sana Safinaz'
            }
        )
    # print(liste)
    return liste
# sana_safina()


def ethnic():
    url = "https://ethnic.pk/collections/mid-season-sale-up-to-50-off"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.find_all("a", {"class": "product-title"})
    sc_newprice = soup.select(".special-price .money")
    sc_oldprice = soup.select(".old-price .money")
    sc_img = soup.find_all("a", {"class": "product-grid-image"})

    # print(len(sc_titles))
    # print(len(sc_newprice))
    # print(len(sc_oldprice))
    # print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://ethnic.pk/"+sc_titles[index]['href']

        oldprice = sc_oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_oldprice) else '0 PKR'
        price = sc_newprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_newprice) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'price': price,
                'image': sc_img[index].find('img')['src'],
                'href':  link,
                'brand': 'ethnic'
            }
        )
    # print(liste)
    return liste
# ethnic()


def outfittersW():
    url = "https://outfitters.com.pk/collections/women-shirts-sale"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-bottom .product-title')
    sc_price = soup.select(".product-bottom .special-price .money")
    sc_oldprice = soup.select(".product-bottom .old-price .money")
    sc_img = soup.select(
        ".grid-item .product-item .inner-top .product-top .image-swap .product-grid-image .images-one")

    # # sc_herf_list = []
    # for index in range(len(sc_img)):
    #     print(len(sc_img[index]["alt"]))
    #     # print(sc_titles[index][])

    # print(len(sc_titles))
    # print(len(sc_oldprice))
    # print(len(sc_price))
    # print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://outfitters.com.pk/"+sc_titles[index]['href']

        oldprice = sc_oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_oldprice) else '0 PKR'
        price = sc_price[index].get_text().strip(
        ) if indexExistInArray(index, sc_price) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'price': price,
                'image': img,
                'href': link,
                'brand': 'Outfitters'
            }
        )
    # print(liste)
    return liste
# outfittersW()


def EdenrobeW():
    url = "https://edenrobe.com/product-category/flash-sale/women"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-item-link')
    sc_newprice = soup.select(".special-price .price")
    sc_oldprice = soup.select(".old-price .price")
    sc_img = soup.select(".product-item-photo img")

    # print(len(sc_titles))
    # print(len(sc_newprice))
    # print(len(sc_oldprice))
    # print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://edenrobe.com/"+sc_titles[index]['href']

        oldprice = sc_oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_oldprice) else '0 PKR'
        price = sc_newprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_newprice) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'price': price,
                'image': img,
                'href': link,
                'brand': 'Edenrobe'
            }
        )
    # print(liste)
    return liste
# EdenrobeW()


def kayseria():
    url = 'https://www.kayseria.com/collections/sale-unstitched'
    page = requests.get(url, headers=headers)

    soup = BeautifulSoup(page.content, 'html.parser')

    sc_imgs = soup.select(".product-image img")
    sc_newprice = soup.select(".special-price")
    sc_oldprice = soup.select(".old-price")
    sc_title = soup.select(".product-title ")

    print(len(sc_imgs))
    print(len(sc_newprice))
    print(len(sc_oldprice))
    print(len(sc_title))

    liste = []
    for index in range(len(sc_title)):
        if sc_imgs[index].has_attr('data-srcset'):
            img = sc_imgs[index]['data-srcset']
        else:
            img = sc_imgs[index]['srcset']

        if findString(sc_title[index]['href'], "https") or findString(sc_title[index]['href'], "http"):
            link = sc_title[index]['href']
        else:
            link = "https://www.kayseria.com/"+sc_title[index]['href']

        oldprice = sc_oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_oldprice) else '0 PKR'
        price = sc_newprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_newprice) else '0 PKR'

        liste.append(
            {
                'title': sc_title[index].get_text().strip(),
                'oldprice': oldprice,
                'price': price,
                'image': img,
                'href': link,
                'brand': 'Kayseria'
            }
        )
    # print(liste)
    return liste

# kayseria()

# def almirah():
#     url = "https://www.almirah.com.pk/collections/all-sale"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select('.grid-product__image-mask .image-wrap noscript img')

#     sc_newprice = soup.select(".money")
#     sc_oldprice = soup.select(".money")
#     sc_title = soup.select(".grid-product__title--body")
#     # pr_lazy_img main-img nt_img_ratio nt_bg_lz lazyloaded
#     # print(len(sc_imgs))
#     # print(len(sc_title))
#     # print(len(sc_price))

#     liste = []
#     for index in range(len(sc_imgs)-1):
#         if sc_imgs[index].has_attr('data-srcset'):
#             img = sc_imgs[index]['data-srcset']
#         else:
#             img = sc_imgs[index]['src']
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand':'almirah'
#             }
#         )
#     # print(liste)
#     return liste
# #almirah()


# def generation():
#     url = "https://www.generation.com.pk/sale.html"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_titles = soup.find_all("a", {"class": "product-item-link"})
#     # sc_price = soup.find_all("span", {"class": "price"})
#     sc_newprice = soup.select(".price-wrapper .price")
#     sc_oldprice = soup.select(".onsale .price")
#     sc_img = soup.find_all("img", {"class": "product-image-photo"})

#     # print(sc_titles[0])
#     liste = []
#     for index in range(len(sc_titles)):
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': sc_img[index]['src'],
#                 'brand': 'generation'
#             }
#         )
#     # print(liste)
#     return liste


# def khaadi():
#     url = "https://pk.khaadi.com/sale/ready-to-wear.html"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_titles = soup.find_all("a", {"class": "product-item-link"})
#     sc_newprice = soup.select(".price-wrapper .price")
#     sc_oldprice = soup.select(".special-price .price")
#     sc_img = soup.find_all("img", {"class": "product-image-photo"})

#     # print(sc_img[0]['data-src'])
#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))
#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'khaadi'
#             }
#         )
#     # print(liste)
#     return liste

# def edenrobe():
#     url = 'https://edenrobe.com/product-category/flash-sale/women'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select(".product-item-photo img ")
    # sc_newprice = soup.select(".special-price .price")
    # sc_oldprice = soup.select(".old-price .price")
#     sc_title = soup.select(".product-item-name")

#     # print(len(sc_imgs))
#     # print(len(sc_price))
#     # print(len(sc_title))


#     liste = []
#     for index in range(len(sc_title)):
#         if sc_imgs[index].has_attr('src'):
#             img = sc_imgs[index]['src']
#         else:

#             img = sc_imgs[index]['data-src']
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'edenrobe'
#             }
#         )
#     # print(liste)
#     return liste

# # edenrobe()

# def SanaSafinaz():
#     url = 'https://www.sanasafinaz.com/us/sale.html'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select(".product-image-container img ")
#     sc_newprice = soup.select(".special-price .price")
#     sc_oldprice = soup.select(".old-price .price")
#     sc_title = soup.select(".product-item-name")

#     # print(len(sc_imgs))
#     # print(len(sc_price))
#     # print(len(sc_title))


#     liste = []
#     for index in range(len(sc_title)):
#         if sc_imgs[index].has_attr('data-src'):
#             img = sc_imgs[index]['data-src']
#         else:

#             img = sc_imgs[index]['src']
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'Sana Safinaz'
#             }
#         )
#     # print(liste)
#     return liste

# # SanaSafinaz()


# def kayseria():
#     url = 'https://www.kayseria.com/sale?p=11'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select(".product-image img")
#     sc_newprice = soup.select(".special-price")
#     sc_oldprice = soup.select(".old-price")
#     sc_title = soup.select(".product-name")

#     # print(len(sc_imgs))
#     # print(len(sc_price))
#     # print(len(sc_title))


#     liste = []
#     for index in range(len(sc_title)):
#         if sc_imgs[index].has_attr('data-src'):
#             img = sc_imgs[index]['data-src']
#         else:

#             img = sc_imgs[index]['src']
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand':'kayseria'
#             }
#         )
#     # print(liste)
#     return liste

# # kayseria()


def getWomenClothes():
    return [sana_safina(), ethnic(), outfittersW(), EdenrobeW(), kayseria()]
    # return [edenrobe(), kayseria(), SanaSafinaz(), generation(), khaadi(), ethnic(), almirah()]

# getWomenData()
