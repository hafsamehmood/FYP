import requests
from bs4 import BeautifulSoup

headers = {"User-agent": 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}

def findString(haystack, needle):
    if haystack.find(needle) != -1:
        return True
    return False

def metro():
    url = "https://www.metroshoes.com.pk/collections/gents"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.select('.product-info .product-info-inner a')
    sc_Oldprice = soup.select(".price .was")
    sc_Newprice = soup.select(".price .onsale")
    sc_img = soup.select(".prod-image .box-ratio img")

    # print(len(sc_titles))
    # print(len(sc_Oldprice))
    # print(len(sc_Newprice))
    # print(len(sc_img))
    
    liste = []
    for index in range(len(sc_titles)):
        img = sc_img[index]['data-original']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://www.metroshoes.com.pk/"+sc_titles[index]['href']

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': sc_Oldprice[index].get_text().strip(),
                'price': sc_Newprice[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'metro'
            }
        )
    # print(liste)
    return liste
# metro()

def Ndure():
    url = "https://www.ndure.com/collections/sale/men"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_imgs = soup.select('.product-grid-image img')
    sc_newprice = soup.select(".price-box .price-sale .special-price")
    sc_oldprice = soup.select(".old-price")
    sc_title = soup.select(".product-title")
    # sc_href = soup.select('.product-image  .product-grid-image')
    # pr_lazy_img main-img nt_img_ratio nt_bg_lz lazyloaded
    
    # print(len(sc_title))
    # print(len(sc_newprice))
    # print(len(sc_oldprice))
    # print(len(sc_imgs))
    # print(len(sc_href))

    liste = []
    for index in range(len(sc_title)):
        if sc_imgs[index].has_attr('data-srcset'):
            img = sc_imgs[index]['data-srcset']
        else:
            img = sc_imgs[index]['srcief']

        if findString(sc_title[index]['href'], "https") or findString(sc_title[index]['href'], "http"):
            link = sc_title[index]['href']
        else:
            link = "https://www.ndure.com/"+sc_title[index]['href']

        liste.append(
            {
                'title': sc_title[index].get_text().strip(),
                'oldprice': sc_oldprice[index].get_text().strip(),
                'price': sc_newprice[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'Ndure'
            }
        )
    # print(liste)
    return liste
# Ndure()


def Borjan():
    url = "https://www.borjan.com.pk/collections/sale-21-men"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-title')
    sc_oldprice = soup.select(".price-box .sale .old-price")
    sc_price = soup.select(".price-box .sale .special-price")
    sc_img = soup.select(".product-grid-image img")

    # print(len(sc_titles))
    # print(len(sc_oldprice))
    # print(len(sc_price))
    # print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://www.borjan.com.pk/"+sc_titles[index]['href']

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': sc_oldprice[index].get_text().strip(),
                'price': sc_price[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'Borjan Shoes'
            }
        )
    # print(liste)
    return liste
# Borjan()



# def MetroShoes():
#     url = 'https://www.metroshoes.com.pk/collections/gents'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select(".reveal .box-ratio img")
#     sc_price = soup.select(".price")
#     sc_title = soup.select(".prod-title")

#     # print(len(sc_imgs))
#     # print(len(sc_price))
#     # print(len(sc_title))
    

#     liste = []
#     for index in range(len(sc_title)):
#         if sc_imgs[index].has_attr('data-original'):
#             img = sc_imgs[index]['data-original']
#         else:
#             img = sc_imgs[index]['srcset']
#         if ((sc_title[index].get_text().strip() != '') and 
#         (sc_price[index].get_text().strip() != '') and 
#         (img != '')):
#             liste.append(
#                 {
#                     'image': img,
#                     'title': sc_title[index].get_text().strip(),
#                     'price': sc_price[index].get_text().strip(),
#                     'brand': 'Metro'
#                 }
#         )
#     # print(liste)
#     return liste

# # MetroShoes()



# def Ndure():
#     url = "https://www.ndure.com/collections/sale-men"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select('.images-two img')
#     # sc_price = soup.select(".product-bottom .price-box .price-sale .old-price ")
#     sc_newprice = soup.select(".special-price")
#     sc_oldprice = soup.select(".old-price")
#     sc_title = soup.select(".product-bottom .product-title span")
#     # pr_lazy_img main-img nt_img_ratio nt_bg_lz lazyloaded
#     # print(len(sc_imgs))
#     # print(len(sc_title))
#     # print(len(sc_price))
#     liste = []
#     for index in range(len(sc_title)-1):
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': sc_imgs[index]['data-srcie'],
#                 'brand':'Ndure'
#             }
#         )
#     # print(liste)
#     return liste
# # Ndure()


# def OxygenShoes():
#     url = "https://www.oxygenshoes.pk/mens-footwear/dress-shoes"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.product-item-name')
    # sc_price = soup.select(".price-final_price")
    # sc_img = soup.select(".product-image-wrapper img")

#     print(len(sc_titles))
#     print(len(sc_price))
#     print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 'price': sc_price[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'OxygenShoes'
#             }
#         )
#     # print(liste)
#     return liste
# # OxygenShoes()


# def LeSole():
#     url = "https://lesoleonline.com/collections/super-offer"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.product-title')
#     # sc_price = soup.select(".price-box")
#     sc_newprice = soup.select(".special-price .money")
#     sc_oldprice = soup.select(".old-price .money")
#     sc_img = soup.select(".product-grid-image img")

#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'Le Sole'
#             }
#         )
#     # print(liste)
#     return liste
# # LeSole()


# def MiliShoes():
#     url = "https://www.millisignature.com/product-category/men/"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.product-title')
#     sc_price = soup.select(".price")
#     sc_img = soup.select(".product-image-link img")

#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 'price': sc_price[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'Mili Shoes'
#             }
#         )
#     # print(liste)
#     return liste
# # MiliShoes()





def getMensShoes():
    return [metro(),Ndure(),Borjan()]
    # return [MetroShoes(), Ndure() ,OxygenShoes(),LeSole(),MiliShoes()]