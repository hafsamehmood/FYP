import requests
from bs4 import BeautifulSoup
from python_modules.globalFunctions import *

headers = {
    "User-agent": 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}


def findString(haystack, needle):
    if haystack.find(needle) != -1:
        return True
    return False


def HopeNotOut():
    url = "https://www.hopenotout.com/collections/hope-not-out-men-sale"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-title')
    sc_Newprice = soup.select(".price-box .special-price")
    sc_Oldprice = soup.select(".price-box .old-price")
    # sc_price = soup.select(".price-box")
    sc_img = soup.select(".product-grid-image img")

    print(len(sc_titles))
    print(len(sc_Newprice))
    print(len(sc_Oldprice))
    print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):

        if indexExistInArray(index, sc_img):
            if sc_img[index].has_attr('data-src'):
                img = sc_img[index]['data-src']
            else:
                img = sc_img[index]['src']
        else:
            img = 'https://user-images.githubusercontent.com/43302778/106805462-7a908400-6645-11eb-958f-cd72b74a17b3.jpg'

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://www.hopenotout.com/"+sc_titles[index]['href']

        oldprice = sc_Oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_Oldprice) else '0 PKR'
        price = sc_Newprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_Newprice) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'price': price,
                'image': img,
                'href': link,
                'brand': 'Hope Not Out'
            }
        )
    # print(liste)
    return liste
# HopeNotOut()


def outfitters():
    url = "https://outfitters.com.pk/collections/men-jeans-sale"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-bottom .product-title')
    sc_price = soup.select(".product-bottom .special-price .money")
    sc_oldprice = soup.select(".product-bottom .old-price .money")
    sc_img = soup.select(
        ".grid-item .product-item .inner-top .product-top .image-swap .product-grid-image .images-one")

    # # sc_herf_list = []
    # for index in range(len(sc_img)):
    #     print(len(sc_img[index]["alt"]))
    #     # print(sc_titles[index][])

    # print(len(sc_titles))
    # print(len(sc_oldprice))
    # print(len(sc_price))
    # print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://outfitters.com.pk/"+sc_titles[index]['href']

        oldprice = sc_oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_oldprice) else '0 PKR'
        price = sc_price[index].get_text().strip(
        ) if indexExistInArray(index, sc_price) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'price': price,
                'image': img,
                'href': link,
                'brand': 'Outfitters'
            }
        )
    # print(liste)
    return liste
# outfitters()


def Edenrobe():
    url = "https://edenrobe.com/product-category/flash-sale/men"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-item-link')
    sc_newprice = soup.select(
        ".normal-price .price-container .price-wrapper .price")
    sc_oldprice = soup.select(".old-price .price")
    sc_img = soup.select(".product-item-photo img")

    # print(len(sc_titles))
    # print(len(sc_newprice))
    # print(len(sc_oldprice))
    # print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://edenrobe.com/"+sc_titles[index]['href']

        oldprice = sc_oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_oldprice) else '0 PKR'
        price = sc_newprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_newprice) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'price': price,
                'image': img,
                'href': link,
                'brand': 'Edenrobe'
            }
        )
    # print(liste)
    return liste
# Edenrobe()


def FurorJeans():
    url = "https://furorjeans.com/sale?product_list_limit=24"

    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-item-name .product-item-link')
    # sc_price = soup.select(".price-box .special-price")
    sc_newprice = soup.select(".special-price .price")
    sc_oldprice = soup.select(".sly-old-price .price")
    sc_img = soup.select(".product-item-photo img")

    # print(len(sc_titles))
    # print(len(sc_newprice))
    # print(len(sc_oldprice))
    # print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://furorjeans.com/"+sc_titles[index]['href']

        oldprice = sc_oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_oldprice) else '0 PKR'
        price = sc_newprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_newprice) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'image': img,
                'href': link,
                'brand': 'Furor Jeans'
            }
        )
    # print(liste)
    return liste
# FurorJeans()


def Fitted():
    url = "https://fittedshop.com/category/winter"

    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-title a')
    # sc_price = soup.select(".product-pd")
    sc_newprice = soup.select(".product-pd .product-price")
    # sc_oldprice = soup.find_all('div')
    sc_oldprice = soup.select(".product-discount")
    sc_img = soup.select(" .product-img img")

    # print(len(sc_titles))
    # print(len(sc_oldprice))
    # print(len(sc_newprice))
    # print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://fittedshop.com/"+sc_titles[index]['href']

        oldprice = sc_oldprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_oldprice) else '0 PKR'
        price = sc_newprice[index].get_text().strip(
        ) if indexExistInArray(index, sc_newprice) else '0 PKR'

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': oldprice,
                'image': img,
                'href': link,
                'brand': 'Fitted'
            }
        )
    # print(liste)
    return liste
# Fitted()


# def outfitters():
#     url = "https://outfitters.com.pk/collections/men-jeans-sale"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.product-title')
#     # sc_price = soup.select(".price-box")
#     sc_newprice = soup.select(".special-price .money")
#     sc_oldprice = soup.select(".old-price .money")
#     sc_img = soup.select(".product-grid-image img")
#     sc_href = soup.select(".product-image a")


#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'outfitters'
#             }
#         )
#     # print(liste)
#     return liste
# # outfitters()

# def uniworth():
#     url = "https://uniworthshop.com/ethnic-wear"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select('.product-image a picture:nth-child(1) img')
#     sc_price = soup.select(".product-price span")
#     # sc_newprice = soup.select(".product-price .price")
#     # sc_oldprice = soup.select(".product-price .old-price")
#     sc_title = soup.select(".product-name a")

#     # print(len(sc_imgs))
#     # print(len(sc_title))
#     # print(len(sc_price))

#     liste = []
#     for index in range(len(sc_title)):
#         if sc_imgs[index].has_attr('src'):
#             img = sc_imgs[index]['src']
#         else:
#             img = sc_imgs[index]['srcset']
#         if ((sc_title[index].get_text().strip() != '') and
#         (sc_price[index].get_text().strip() != '') and
#         (img != '')):
#             liste.append(
#                 {
#                     'image': img,
#                     'price': sc_price[index].get_text().strip(),
#                     # 'price': sc_newprice[index].get_text().strip(),
#                     # 'oldprice': sc_oldprice[index].get_text().strip(),
#                     'title': sc_title[index].get_text().strip(),
#                     'brand':'uniworth'
#                 }
#         )
#     # print(liste)
#     return liste
# # uniworth()

# def edenrobe():
#     url = 'https://edenrobe.com/product-category/flash-sale/men'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select(".product-item-photo img ")
#     sc_newprice = soup.select(".normal-price .price")
#     sc_oldprice = soup.select(".price-container .price")
#     sc_title = soup.select(".product-item-name")

#     # print(len(sc_imgs))
#     # print(len(sc_price))
#     # print(len(sc_title))


#     liste = []
#     for index in range(len(sc_title)):
#         if sc_imgs[index].has_attr('src'):
#             img = sc_imgs[index]['src']
#         else:

#             img = sc_imgs[index]['data-src']
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'edenrobe'
#             }
#         )
#     # print(liste)
#     return liste

# # edenrobe()


def SaeedAjmal():
    url = "https://www.saeedajmalstores.com/collections/mens-kameez-shalwar"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-title')
    sc_price = soup.select(".price-box")
    # sc_newprice = soup.select(".special-price .money")
    # sc_oldprice = soup.select(".old-price .money")
    sc_img = soup.select(".product-grid-image img")

    # print(len(sc_titles))
    # print(len(sc_price))
    # print(len(sc_img))

    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']
        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'price': sc_price[index].get_text().strip(),
                # 'oldprice': sc_oldprice[index].get_text().strip(),
                'image': img,
                'brand':'Saeed Ajmal'
            }
        )
    # print(liste)
    return liste
# SaeedAjmal()

# def HopeNotOut():
#     url = "https://www.hopenotout.com/collections/hope-not-out-men-sale"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.product-title')
#     sc_newprice = soup.select(".price-box .special-price")
#     sc_oldprice = soup.select(".price-box .old-price")
#     # sc_price = soup.select(".price-box")
#     sc_img = soup.select(".product-grid-image img")

#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'Hope Not Out'
#             }
#         )
#     # print(liste)
#     return liste
# # HopeNotOut()


# def FurorJeans():
#     url = "https://furorjeans.com/flat-50-off?product_list_limit=36"

#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.product-item-name')
#     # sc_price = soup.select(".price-box .special-price")
#     sc_newprice = soup.select(".special-price .price")
#     sc_oldprice = soup.select(".sly-old-price .price")
#     sc_img = soup.select(".product-item-photo img")

#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('src'):
#             img = sc_img[index]['src']
#         else:
#             img = sc_img[index]['data-src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'Furor Jeans'
#             }
#         )
#     # print(liste)
#     return liste
# # FurorJeans()

# def LondonBridge():
#     url = "https://londonbridge.com.pk/collections/clearance"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.title')
#     # sc_price = soup.select(".price")
#     sc_newprice = soup.select(".current_price .money")
#     sc_oldprice = soup.select(".was_price .money")
#     sc_img = soup.select(".product_image .image-element__wrap img")

#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'London Bridge'
#             }
#         )
#     # print(liste)
#     return liste
# # LondonBridge()


# def Fitted():
#     url = "https://fittedshop.com/category/sale"

#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.product-title')
#     # sc_price = soup.select(".product-pd")
#     sc_newprice = soup.select(".product-price")
#     # sc_oldprice = soup.find_all('div')
#     sc_oldprice = soup.select(".product-price")
#     sc_img = soup.select(" .product-img img")

#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'Fitted'
#             }
#         )
#     # print(liste)
#     return liste
# # Fitted()


def getMenClothes():
    return [Edenrobe(), outfitters(), Fitted(), FurorJeans(), SaeedAjmal()]
    # return [outfitters(), HopeNotOut(), uniworth(), edenrobe(),SaeedAjmal(),FurorJeans(),LondonBridge(),Fitted()]
