import requests
from bs4 import BeautifulSoup

headers = {"User-agent": 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}

def findString(haystack, needle):
    if haystack.find(needle) != -1:
        return True
    return False

def Hopscotch():
    url = "https://www.ilovehopscotch.com/sale-mini-girl.html"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.select('.product-item-link')
    sc_Oldprice = soup.select(".price")
    sc_Newprice = soup.select(".onsale")
    sc_img = soup.select(".product-image-photo")

    # print(len(sc_titles))
    # print(len(sc_Oldprice))
    # print(len(sc_Newprice))
    # print(len(sc_img))

    
    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://www.ilovehopscotch.com/"+sc_titles[index]['href']

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': sc_Oldprice[index].get_text().strip(),
                'price': sc_Newprice[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'Hopscotch'
            }
        )
    # print(liste)
    return liste
# Hopscotch()

def sana_safina():
    url = "https://www.sanasafinaz.com/pk/catalog/category/view/s/kids/id/718/"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.select('.product-item-link')
    sc_Oldprice = soup.select("span[data-price-type='oldPrice'] .price")
    sc_Newprice = soup.select("span[data-price-type='finalPrice'] .price")
    sc_img = soup.select(".product-item-photo img:first-child")
    
    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://www.sanasafinaz.com.pk/"+sc_titles[index]['href']

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': sc_Oldprice[index].get_text().strip(),
                'price': sc_Newprice[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'Sana Safinaz'
            }
        )
    # print(liste)
    return liste
# sana_safina()

def ethnic():
    url = "https://ethnic.pk/collections/cottage-1902-ss21-kids"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.find_all("a", {"class": "product-title"})
    sc_newprice = soup.select(".special-price .money")
    sc_oldprice = soup.select(".old-price .money")
    sc_img = soup.find_all("a", {"class": "product-grid-image"})

    # print(len(sc_titles))
    # print(len(sc_newprice))
    # print(len(sc_oldprice))
    # print(len(sc_img))

    
    

    liste = []
    for index in range(len(sc_titles)):

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://ethnic.pk/"+sc_titles[index]['href']

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': sc_oldprice[index].get_text().strip(),
                'price': sc_newprice[index].get_text().strip(),
                'image': sc_img[index].find('img')['src'],
                'href':  link,
                'brand': 'ethnic'
            }
        )
    # print(liste)
    return liste
# ethnic()


# def Leisure():
#     url = 'https://www.leisureclub.pk/collections/kids-sale/kids-sale'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_title= soup.select('.product-thumb-caption-title')
#     # sc_price = soup.select(".product-thumb-caption-price-current .money ")
#     sc_newprice = soup.select(".product-thumb-caption-price-current .money")
#     sc_oldprice = soup.select(".product-thumb-caption-price-list .compare-price.money")
#     sc_imgs = soup.select(".blur-up")
#     # print(len(sc_title))
#     # print(len(sc_price))
#     # print(len(sc_imgs))
#     liste = []
   
#     for index in range(len(sc_title)):
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': sc_imgs[index]['src'],
#                 'brand':'Leisure'
#             }
#         )
    
#     return liste
# def Hopscotch():
#     url = 'https://www.ilovehopscotch.com/sale-mini-girl.html'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_title= soup.select('.product-item-link')
#     sc_price = soup.select(".price")
#     # sc_newprice = soup.select(".price")
#     # sc_oldprice = soup.select(".b")
#     # sc_img = soup.find_all("img", {"class": "price"})
#     sc_imgs = soup.select(".product-image-photo")
#     # print(len(sc_title))
#     # print(len(sc_price))
#     # print(len(sc_imgs))
#     liste = []
   
#     for index in range(len(sc_title)):
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 'price': sc_price[index].get_text().strip(),
#                 # 'price': sc_newprice[index].get_text().strip(),
#                 # 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': sc_imgs[index]['src'],
#                 'brand':'Hopscotch'
#             }
#         )
#     # print(liste)
#     return liste
# # Hopscotch()

# def SanaSafinaz():
#     url = 'https://www.sanasafinaz.com/pk/catalog/category/view/s/kids/id/718/'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select(".product-image-container img ")
#     # sc_price = soup.select(".price-box .price ") 
#     sc_newprice = soup.select(".special-price .price")
#     sc_oldprice = soup.select(".old-price .price")
#     sc_title = soup.select(".product-item-name")

#     # print(len(sc_imgs))
#     # print(len(sc_price))
#     # print(len(sc_title))
    

#     liste = []
#     for index in range(len(sc_title)):
#         if sc_imgs[index].has_attr('data-src'):
#             img = sc_imgs[index]['data-src']
#         else:

#             img = sc_imgs[index]['src']
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                  'price': sc_newprice[index].get_text().strip(),
#                  'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'Sana Safinaz'
#             }
#         )
#     # print(liste)
#     return liste

# # SanaSafinaz()

# def ethnic():
#     url = "https://ethnic.pk/collections/mid-season-sale-kids"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_titles = soup.find_all("a", {"class": "product-title"})
#     # sc_price = soup.find_all("span", {"class": "money"})
#     sc_newprice = soup.select(".special-price .money")
#     sc_oldprice = soup.select(".old-price .money")
#     sc_img = soup.find_all("a", {"class": "product-grid-image"})

#     # print(sc_titles[0])

#     # print(len(sc_img))
#     # print(len(sc_price))
#     # print(len(sc_titles))

#     liste = []
#     for index in range(len(sc_titles)):
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': sc_img[index].find('img')['src'],
#                 'brand': 'ethnic'
#             }
#         )
#     # print(liste)
#     return liste
# # ethnic()

# def kayseria():
#     url = 'https://www.kayseria.com/sale/kids?p=2'

#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select(".product-image img")
#     sc_price = soup.select(".price-box")
#     sc_title = soup.select(".product-name")

#     # print(len(sc_imgs))
#     # print(len(sc_price))
#     # print(len(sc_title))
    

#     liste = []
#     for index in range(len(sc_title)):
#         if sc_imgs[index].has_attr('data-src'):
#             img = sc_imgs[index]['data-src']
#         else:

#             img = sc_imgs[index]['src']
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 'price': sc_price[index].get_text().strip(),
#                 'image': img,
#                 'brand':'kayseria'
#             }
#         )
#     # print(liste)
#     return liste

# # kayseria()


# def outfitters():
#     url = "https://outfitters.com.pk/collections/junior-sale-2021"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.product-title')
#     # sc_price = soup.select(".price-box")
#     sc_newprice = soup.select(".special-price .money")
#     sc_oldprice = soup.select(".old-price .money")
#     sc_img = soup.select(".product-grid-image img")
  
#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))
  
#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'outfitters'
#             }
#         )
#     # print(liste)
#     return liste
# # outfitters()


def outfittersK():
    url = "https://outfitters.com.pk/collections/boys-t-shirts-sale"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
    sc_titles = soup.select('.product-bottom .product-title')
    sc_price = soup.select(".product-bottom .special-price .money")
    sc_oldprice = soup.select(".product-bottom .old-price .money")
    sc_img = soup.select(".grid-item .product-item .inner-top .product-top .image-swap .product-grid-image .images-one")
    
    # # sc_herf_list = []
    # for index in range(len(sc_img)):
    #     print(len(sc_img[index]["alt"]))
    #     # print(sc_titles[index][])


   
    # print(len(sc_titles))
    # print(len(sc_oldprice))
    # print(len(sc_price))
    # print(len(sc_img))


    liste = []
    for index in range(len(sc_titles)):
        if sc_img[index].has_attr('data-src'):
            img = sc_img[index]['data-src']
        else:
            img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://outfitters.com.pk/"+sc_titles[index]['href']

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': sc_oldprice[index].get_text().strip(),
                'price': sc_price[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'Outfitters'
            }
        )
    # print(liste)
    return liste
# outfittersK()

def getKidsClothes():
    return[sana_safina(),ethnic(),Hopscotch(),outfittersK()]
    # return [SanaSafinaz(), kayseria(),Leisure(),Hopscotch(),ethnic(),outfitters()]