import requests
from bs4 import BeautifulSoup

headers = {"User-agent": 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}

def findString(haystack, needle):
    if haystack.find(needle) != -1:
        return True
    return False

def metro():
    url = "https://www.metroshoes.com.pk/collections/women/slides"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.select('.product-info .product-info-inner a')
    sc_Oldprice = soup.select(".price .was")
    sc_Newprice = soup.select(".price .onsale")
    sc_img = soup.select(".prod-image .box-ratio img")

    # print(len(sc_titles))
    # print(len(sc_Oldprice))
    # print(len(sc_Newprice))
    # print(len(sc_img))
    
    liste = []
    for index in range(len(sc_titles)):
        img = sc_img[index]['data-original']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://www.metroshoes.com.pk/"+sc_titles[index]['href']

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': sc_Oldprice[index].get_text().strip(),
                'price': sc_Newprice[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'metro'
            }
        )
    # print(liste)
    return liste
# metro()

def Ndure():
    url = "https://www.ndure.com/collections/sale/women"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_imgs = soup.select('.product-grid-image img')
    sc_newprice = soup.select(".price-box .price-sale .special-price")
    sc_oldprice = soup.select(".old-price")
    sc_title = soup.select(".product-title")
    # sc_href = soup.select('.product-image  .product-grid-image')
    # pr_lazy_img main-img nt_img_ratio nt_bg_lz lazyloaded
    
    # print(len(sc_title))
    # print(len(sc_newprice))
    # print(len(sc_oldprice))
    # print(len(sc_imgs))
    # print(len(sc_href))

    liste = []
    for index in range(len(sc_title)):
        if sc_imgs[index].has_attr('data-srcset'):
            img = sc_imgs[index]['data-srcset']
        else:
            img = sc_imgs[index]['srcief']

        if findString(sc_title[index]['href'], "https") or findString(sc_title[index]['href'], "http"):
            link = sc_title[index]['href']
        else:
            link = "https://www.ndure.com/"+sc_title[index]['href']

        liste.append(
            {
                'title': sc_title[index].get_text().strip(),
                'oldprice': sc_oldprice[index].get_text().strip(),
                'price': sc_newprice[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'Ndure'
            }
        )
    # print(liste)
    return liste
# Ndure()

def stylo():
    url = "https://stylo.pk/collections/sale"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.select('.grid-view-item__title')
    sc_Oldprice = soup.select(".regular")
    sc_Newprice = soup.select(".product-price__sale")
    sc_img = soup.select(".grid-view-item__link img:first-child")

    # print(len(sc_titles))
    # print(len(sc_Oldprice))
    # print(len(sc_Newprice))
    # print(len(sc_img))
    
    liste = []
    for index in range(len(sc_titles)):
        img = sc_img[index]['src']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://stylo.pk/"+sc_titles[index]['href']

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': sc_Oldprice[index].get_text().strip(),
                'price': sc_Newprice[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'stylo'
            }
        )
    # print(liste)
    return liste
# stylo()

def eng_shoes():
    url = "https://englishshoesonline.com/product-category/women-shoes/"
    page = requests.get(url, headers=headers)
    soup = BeautifulSoup(page.content, 'html.parser')

    sc_titles = soup.select('.theme-extends-woo-loop-item-wrap-entry a')
    sc_Newprice = soup.select(".theme-extends-woo-loop-item-wrap-entry .price ins .woocommerce-Price-amount bdi")
    sc_Oldprice = soup.select(".theme-extends-woo-loop-item-wrap-entry .price del .woocommerce-Price-amount bdi")
    sc_img = soup.select(".theme-extends-woo-product-thumbnail-background")

    # print(len(sc_titles))
    # print(len(sc_Oldprice))
    # print(len(sc_Newprice))
    # print(len(sc_img))
    
    liste = []
    for index in range(len(sc_titles)):
        img = sc_img[index]['data-background-image-lazyload-onload']

        if findString(sc_titles[index]['href'], "https") or findString(sc_titles[index]['href'], "http"):
            link = sc_titles[index]['href']
        else:
            link = "https://englishshoesonline.com/"+sc_titles[index]['href']

        liste.append(
            {
                'title': sc_titles[index].get_text().strip(),
                'oldprice': sc_Oldprice[index].get_text().strip(),
                'price': sc_Newprice[index].get_text().strip(),
                'image': img,
                'href': link,
                'brand': 'English Shoes'
            }
        )
    # print(liste)
    return liste
# eng_shoes()


# def ecs():
#     url = 'https://shopecs.com/women'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_titles = soup.find_all("a", {"class": "product-item-link"})
#     sc_price = soup.find_all("span", {"class": "price"})
#     sc_img = soup.find_all("img", {"class": "product-image-photo"}) 

#     liste = []
#     for index in range(len(sc_titles)):
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 'price': sc_price[index].get_text().strip(),
#                 'image': sc_img[index]['data-src'],
#                 'brand': 'ecs'
#             }
#         )
#     # print(liste)
#     return liste

# # ecs()


# def Metro():
#     url = 'https://www.metroshoes.com.pk/collections/sale'
#     page = requests.get(url, headers=headers)

#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select(".reveal .box-ratio img")
#     sc_price = soup.select(".price ")
#     # sc_newprice = soup.select(".price .onsale")
#     # sc_oldprice = soup.select(".price .was gsContent")
#     sc_title = soup.select(".prod-title")

#     # print(len(sc_imgs))
#     # print(len(sc_price))
#     # print(len(sc_title))
    

#     liste = []
#     for index in range(len(sc_title)):
#         if sc_imgs[index].has_attr('data-original'):
#             img = sc_imgs[index]['data-original']
#         else:
#             img = sc_imgs[index]['srcset']
#         if ((sc_title[index].get_text().strip() != '') and 
#         (sc_price[index].get_text().strip() != '') and 
#         (img != '')):
#             liste.append(
#                 {
#                     'image': img,
#                     'title': sc_title[index].get_text().strip(),
#                     'price': sc_price[index].get_text().strip(),
#                     # 'oldprice': sc_oldprice[index].get_text().strip(),
#                     'brand': 'Metro'
#                 }
#         )
#     # print(liste)
#     return liste

# # Metro()

# def Ndure():
#     url = "https://www.ndure.com/collections/sale-women"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     sc_imgs = soup.select('.images-two img')
#     sc_newprice = soup.select(".special-price")
#     sc_oldprice = soup.select(".old-price")
#     sc_title = soup.select(".product-bottom .product-title span")
   
#     # pr_lazy_img main-img nt_img_ratio nt_bg_lz lazyloaded
#     # print(len(sc_imgs))
#     # print(len(sc_title))
#     # print(len(sc_price))
   
#     liste = []
#     for index in range(len(sc_newprice)-1):
#         liste.append(
#             {
#                 'title': sc_title[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': sc_imgs[index]['data-srcie'],
#                 'brand':'Ndure'
#             }
#         )
#     # print(liste)
#     return liste
# # Ndure()

# def EnglishShoes():
#     url = "https://englishshoesonline.com/product-category/women-shoes/"
    
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.woocommerce-loop-product__title')
#     sc_newprice = soup.select(".woocommerce-Price-amount")
#     sc_oldprice = soup.select(".woocommerce-Price-amount")
#     # sc_price = soup.select(".price")
#     sc_img = soup.select(".container-image-and-badge img")

#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 # 'price': sc_price[index].get_text().strip(),
#                 'price': sc_newprice[index].get_text().strip(),
#                 'oldprice': sc_oldprice[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'English Shoes'
#             }
#         )
#     # print(liste)
#     return liste
# # EnglishShoes()


# def OxygenShoes():
#     url = "https://www.oxygenshoes.pk/womens-footwear?_=1627205716986&is_ajax=1&p=3"
#     page = requests.get(url, headers=headers)
#     soup = BeautifulSoup(page.content, 'html.parser')

#     # sc_titlesDiv = soup.find_all("div", {"class": "product-bottom"})
#     sc_titles = soup.select('.product-item-name')
#     sc_price = soup.select(".price-final_price")
#     sc_img = soup.select(".product-image-wrapper img")

#     # print(len(sc_titles))
#     # print(len(sc_price))
#     # print(len(sc_img))

#     liste = []
#     for index in range(len(sc_titles)):
#         if sc_img[index].has_attr('data-src'):
#             img = sc_img[index]['data-src']
#         else:
#             img = sc_img[index]['src']
#         liste.append(
#             {
#                 'title': sc_titles[index].get_text().strip(),
#                 'price': sc_price[index].get_text().strip(),
#                 'image': img,
#                 'brand': 'OxygenShoes'
#             }
#         )
#     # print(liste)
#     return liste
# # OxygenShoes()


def getWomenShoes():
    return[Ndure(),eng_shoes(),stylo()]
    # return [Ndure(),EnglishShoes(),OxygenShoes(), Metro(), ecs()]
